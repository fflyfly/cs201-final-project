class Vertex:
    def __init__(self,v):
        self.name = v
        self.neighbours = set()
        self.nn = 0
    def insert_v(self,n):
        self.neighbours.add(n)
        self.nn = len(self.neighbours)
class Graph:
    def __init__(self,n=0,m=0):
        self.n = n
        self.m = m
        self.vs = []
        for i in range(n):
            self.vs.append(Vertex(i))
    def insert_edge(self,st,ed):
        self.vs[st].insert_v(ed)
        self.vs[ed].insert_v(st)

n,m = map(int,input().split())
g = Graph(n,m)
for _ in range(m):
    s,e = map(int,input().split())
    g.insert_edge(s,e)
ans = [[0]*n for _ in range(n)]
for i in range(n):
    for j in range(n):
        if i==j:
            ans[i][j] = g.vs[i].nn
        elif j in g.vs[i].neighbours:
            ans[i][j] = -1
        else:
            ans[i][j] = 0
for i in range(n):
    print(' '.join(map(str,ans[i])))