T = int(input())
nums = list(map(int,input().strip().split()))
def able(T,nums):
    ok = False
    if T==0:
        return 0 in nums
    n = len(nums)
    for i in range(1,1<<n):#n=3:1000 101
        tmp = 1
        for j in range(n):

            if i>>(n-j-1) & 1:
                tmp*=nums[j]
        if tmp==T:
            ok = True
            return ok
    return False
print("YES" if able(T,nums) else "NO")
#1<<3 = 1000  111: j=0 n-j-1