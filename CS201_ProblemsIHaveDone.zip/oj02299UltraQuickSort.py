
ans = 0
lst = []
tmp = []
def merge(left,mid,right):
    global ans
    global lst
    global tmp
    i = left
    j = mid+1
    k = left
    while i<=mid and j<=right:
        if lst[i]<=lst[j]:
            tmp[k] = lst[i]
            k+=1
            i+=1
        else:
            ans+=j-k
            tmp[k] = lst[j]
            k+=1
            j+=1
    while i<=mid:
        tmp[k] = lst[i]
        k += 1
        i += 1
    while j<=right:
        tmp[k] = lst[j]
        k += 1
        j += 1

    for i in range(left,right+1):
        lst[i] = tmp[i]


def mergesort(left,right):
    global ans
    global lst
    global tmp
    if left<right:
        mid = (left+right)//2
        mergesort(left,mid)
        mergesort(mid+1,right)
        merge(left,mid,right)

while True:
    n = int(input())
    ans = 0
    if not n:
        break
    lst = []
    for i in range(n):
        lst.append(int(input()))
    tmp = [0] * len(lst)
    mergesort(0,n-1)
    print(ans)
