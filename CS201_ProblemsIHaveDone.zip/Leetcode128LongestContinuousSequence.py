class Solution(object):
    def longestConsecutive(self, nums):
        """
        :type nums: List[int]
        :rtype: int
        """
        num = set(nums)
        ans = 0
        for x in num:
            if x-1 not in num:
                y = x
                while y in num:
                    y+=1
                ans = max(ans,y-x)
        return ans
a = Solution()
print(a.longestConsecutive([0,3,7,2,5,8,4,6,0,1]))