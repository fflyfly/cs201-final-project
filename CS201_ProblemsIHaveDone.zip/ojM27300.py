n = int(input().strip())

models = {}
for _ in range(n):
    lines = input().strip()
    pos = lines.rfind('-')
    name = lines[:pos]
    size_str = lines[pos+1:]
    unit = size_str[-1].upper()
    num = float(size_str[:-1])
    if unit == "B":
        num*=1000
    size_M = num
    if name not in models:
        models[name] = []
    models[name].append((size_M,size_str))

#print(models)
for name in sorted(models.keys()):
    lst = sorted(models[name],key=lambda x: x[0])
    out = name+": "
    for i in range(len(lst)):
        out+=lst[i][1]
        if i!=len(lst)-1:
           out+=", "
    print(out)


