class Solution(object):
    def decodeString(self, s):
        ans = ""
        stack = []
        nownum = 0
        nowstr = ""
        for ch in s:
            if ch.isdigit():
                nownum = nownum*10+int(ch)
            elif ch == '[':
                stack.append((nownum,nowstr))
                nownum = 0
                nowstr = ""
            elif ch==']':
                num,str = stack.pop()
                nowstr = str+num*nowstr
            else:
                nowstr+=ch
        return nowstr

a = Solution()
print(a.decodeString("3[a]2[bc]"))