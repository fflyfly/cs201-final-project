import heapq
n = int(input())
lst = list(map(int,input().split()))
#print(lst)
left_max_heapq = []
right_min_heapq = []
for i,ch in enumerate(lst):
    if not left_max_heapq or ch <= -left_max_heapq[0]:
        heapq.heappush(left_max_heapq,-ch)
    else:
        heapq.heappush(right_min_heapq,ch)
    if len(left_max_heapq) - len(right_min_heapq)>=2:
        heapq.heappush(right_min_heapq,-heapq.heappop(left_max_heapq))
    elif len(left_max_heapq)< len(right_min_heapq):
        heapq.heappush(left_max_heapq, -heapq.heappop(right_min_heapq))
    if i%2==0:
        print(-left_max_heapq[0])