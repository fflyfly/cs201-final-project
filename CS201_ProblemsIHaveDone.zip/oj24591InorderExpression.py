n = int(input())
hao = ['+','-','*','/']
for _ in range(n):
    str = input()
    s = []
    stack = []
    def operate(s1):
        global stack
        stack1 = []
        for i, ch in enumerate(s1):
            if ch == '(':
                stack1.append(i)
            elif ch == ')':
                stack += operate(s1[stack1.pop()+1:i])
            elif ch in hao:
                stack.append(float(s1[:ch]))
                sta
