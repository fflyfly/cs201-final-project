n = int(input())
for _ in range(n):
    mid = input()
    back = input()
    ans = []
    dic = {}
    def out(lmid,lback,floor):
        root = lback[-1]
        idx = lmid.find(root)
        midleft = lmid[:idx]
        if idx!=len(lmid)-1:
            midright = lmid[idx+1:]
        else:
            midright = []
        backleft,backright = [],[]
        for ch in lback[:-1]:
            if ch in midleft:
                backleft.append(ch)
            else:backright.append(ch)
        if midleft:
            out(midleft,backleft,floor+1)
        if midright:
            out(midright,backright,floor+1)
        if floor not in dic:
            dic[floor] = [root]
        else:
            dic[floor].append(root)
    out(mid,back,0)
    #print(dic)
    for i in sorted(dic):
        ans = ans+dic[i]
    #print(dic)
    print(''.join(ans))




