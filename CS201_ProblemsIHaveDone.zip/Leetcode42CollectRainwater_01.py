class Solution(object):
    def trap(self, height):
        """
        :type height: List[int]
        :rtype: int
        """
        ans = 0
        leftmax = [0]*len(height)
        rightmax = [0] * len(height)
        tmp = 0
        for i in range(len(height)-1):
            tmp = max(tmp,height[i])
            #print(f"i={i},tmp={tmp}")
            leftmax[i+1] = tmp
        #print(leftmax)
        tmp=0
        for i in range(len(height)-1,0,-1):
            tmp = max(tmp,height[i])
            #print(f"i={i},tmp={tmp}")
            rightmax[i-1] = tmp
        #print(rightmax)
        for i in range(1,len(height)-1):
            #print(i,leftmax[i],rightmax[i],height[i])
            if min(leftmax[i],rightmax[i])-height[i]>0:
                #print(min(leftmax[i],rightmax[i])-height[i])
                ans+=min(leftmax[i],rightmax[i])-height[i]
        return ans
a = Solution()
print(a.trap([0,1,0,2,1,0,1,3,2,1,2,1]))