import sys
sys.setrecursionlimit(10**7)

def tree_select_or_not(n, edges, val, root=0, one_indexed=False):
    """
    n: 点数
    edges: [(u,v), ...]  无向边
    val[u]: 选中节点u的收益/权值
    root: 任意选个根
    one_indexed: 若输入点编号1..n则True，从0开始则false

    return: 最优值
    """
    g = [[] for _ in range(n)]
    if one_indexed:
        for a, b in edges:
            a -= 1; b -= 1
            g[a].append(b); g[b].append(a)
    else:
        for a, b in edges:
            g[a].append(b); g[b].append(a)

    dp0 = [0] * n
    dp1 = [0] * n

    def dfs(u, p):#p为u的父节点
        dp1[u] = val[u]     # 选u，先拿到val[u]
        dp0[u] = 0          # 不选u，先从0开始加
        for v in g[u]:
            if v == p:
                continue
            dfs(v, u)
            dp1[u] += dp0[v]
            dp0[u] += max(dp0[v], dp1[v])

    dfs(root, -1)
    return max(dp0[root], dp1[root])

n = int(input())
val = [0]*(n+1)
for i in range(n):
    val[i+1] = int(input())
edges = []
has_parents = [False]*(n+1)
for _ in range(n-1):
    s,t = map(int,input().split())
    has_parents[t] = True
    edges.append((s,t))
root = 1
for i in range(1,n+1):
    if not has_parents[i]:
        root = i
        break
val0 = [val[i] for i in range(1,n+1)]
ans = tree_select_or_not(n,edges, val0, root,one_indexed=True)
print(ans)