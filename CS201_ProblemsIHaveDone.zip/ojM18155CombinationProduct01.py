T = int(input())
nums1 = list(map(int,input().strip().split()))

nums = []
for ch in nums1:
    if ch!=0 and T%ch==0:
        nums.append(ch)

used = [False]*len(nums)#试过i之后，如果成功了就true，如果没成功说明i不可能出现在正确组合里面，之后也不用尝试i了

def dfs(T):
    if T ==0:
        return 0 in nums1
    #print(f"T={T}")
    #print(f"used = {used}")

    for i,m in enumerate(nums):
        #print(f"m={m}")
        if T%m==0 and not used[i]:
            used[i] = True
            if T==m:
                return True
            elif dfs(T//m):
                return True

            used[i] = False

    return False
if dfs(T):
    print("YES")
else:
    print("NO")