class Solution(object):
    def findOcurrences(self, text, first, second):
        """
        :type text: str
        :type first: str
        :type second: str
        :rtype: List[str]
        """
        ans = []
        line = text.strip().split()
        for i in range(len(line)-2):
            if line[i] == first and line[i+1]==second:
                ans.append(line[i+2])
        return ans
a = Solution()
print(a.findOcurrences("alice is a good girl she is a good student","a","good"))