n,m,l = map(int,input().split())
edges = []
for _ in range(m):
    a,b = map(int,input().split())
    edges.append((a,b))
start = int(input())
def build_graph(n, edges, directed=True):
    g = [[] for _ in range(n)]  # 1..n，若你是 0..n-1 就改成 n
    for u, v in edges:
        g[u].append(v)
        if not directed:
            g[v].append(u)
    for ch in g:
        ch.sort()
    return g
g = build_graph(n,edges,directed=False)
#print(g)
visited = [False]*n
step = 0
ans = []
def dfs(u):
    global step
    if step>l:
        return
    ans.append(u)
    #print(ans)
    for v in g[u]:
        if not visited[v] and v not in ans:
            visited[v] = True
            step+=1
            dfs(v)
            step-=1
            visited[v] = False
visited[start] = True
dfs(start)
#ans.sort()
print(' '.join([str(x) for x in ans]))