class Solution(object):
    def generate(self, numRows):
        """
        :type numRows: int
        :rtype: List[List[int]]
        """
        ans = []
        ans.append([1])

        if numRows==1:
            return ans
        ans.append([1, 1])
        if numRows ==2:
            return ans
        for i in range(3,numRows+1):
            tmp = [1]
            pre = ans[-1]
            for j in range(i-2):
                tmp.append(pre[j]+pre[j+1])
            tmp.append(1)
            ans.append(tmp)
        return ans
a = Solution()
print(a.generate(6))