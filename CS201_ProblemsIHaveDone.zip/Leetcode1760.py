class Solution(object):
    def minimumSize(self, nums, maxOperations):
        """
        :type nums: List[int]
        :type maxOperations: int
        :rtype: int
        """
        right = max(nums)#right是一定可行的
        left = 1#left是一定不行的
        middle = (left+right)//2
        if self.able(left):
            return left
        while left<(right-1) :

            if self.able(middle,nums,maxOperations):
                right=middle
                middle = (left+right)//2
            else:
                left=middle
                middle=(left+right)//2
        return right
    def able(self,x,nums,maxOperations):
        _count=0
        for num in nums:
            if num%x==0:
                _count+=num/x
            else:
                _count+=num//x+1

        return (_count-len(nums))<=maxOperations


test = Solution()
print(test.minimumSize([9],200))