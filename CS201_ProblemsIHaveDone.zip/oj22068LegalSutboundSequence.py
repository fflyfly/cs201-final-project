import sys
def able(s,line):
    if len(line) !=len(s):
        return False
    stack = []
    i=0
    nowstr = ""
    for ch in s:
        stack.append(ch)
        while stack and i<len(line) and stack[-1]==line[i]:
            nowstr += stack.pop()
            i+=1
    return nowstr == line

s = input().strip()
for line in sys.stdin:
    line = line.strip()
    if not line:
        continue
    if able(s,line):
        print("YES")
    else:
        print("NO")
