n = int(input())
lst = list(map(int,input().split()))
ans = []
def back(s):
    root = s[0]
    left= []
    right = []
    for ch in s:
        if ch<root:
            left.append(ch)
        elif ch>root:
            right.append(ch)
    if left:
        back(left[:])
    if right:
        back(right[:])
    ans.append(root)
back(lst)
print(' '.join(map(str,ans)))