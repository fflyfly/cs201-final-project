# Definition for singly-linked list.1234
def build_list(nums):
    dummy = ListNode()
    cur = dummy
    for x in nums:
        cur.next = ListNode(x)
        cur = cur.next
    return dummy.next
from typing import Optional
class ListNode:
    def __init__(self, val=0, next=None):
        self.val = val
        self.next = next
class Solution:
    def isPalindrome(self, head: Optional[ListNode]) -> bool:#123456
        fast,slow = head,head
        p2 = head
        len = 0
        while p2:
            len += 1
            p2 = p2.next
        #print(len)
        while fast.next and fast.next.next:
            slow = slow.next
            fast = fast.next.next
        #此时slow到中间或者中间左边那个
        slow = slow.next
        # 此时slow到中间右边1个或者中间右边那个1234:3  12345:4
        p1,now = head,head
        pre = None
        while p1!=slow:
            p1 = p1.next
            now.next = pre
            pre = now
            now = p1
        p1 = pre
        #p1 = 1234:2 12345:3

        if len%2!=0:
            p1 = p1.next
        while p1:
            if p1.val!=slow.val:
                return False
            p1 = p1.next
            slow = slow.next
        return True
head = build_list([1])
a = Solution()
print(a.isPalindrome(head))