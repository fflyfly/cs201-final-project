import math
a = int(input().strip())
prime = [1]*(a+1)#0：不是质数；1：是质数
prime[0] = prime[1] = 0
for i in range(2,int(a**0.5)+1):
    if prime[i]:
        for j in range(i*i,a+1,i):
            prime[j]=0

for i in range(a//2):
    if prime[i] and prime[a-i]:
        print(i,a-i)