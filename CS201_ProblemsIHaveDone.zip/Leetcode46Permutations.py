class Solution(object):
    def permute(self, nums):
        """
        :type nums: List[int]
        :rtype: List[List[int]]
        """
        #nums = [1,2,4]
        ans = []
        tmp = []
        used = [False]*len(nums)
        def dfs():
            if len(tmp)==len(nums):
                ans.append(tmp[:])
                return
            else:
                for i,m in enumerate(nums):
                    if used[i]:
                        continue
                    used[i]=True
                    tmp.append(m)
                    dfs()
                    used[i]=False
                    tmp.pop()
        dfs()
        return ans

a = Solution()
print(a.permute([1,2,3]))