def trap(height):
    n = len(height)
    if n < 3:
        return 0
    l, r = 0, n - 1
    Lmax, Rmax = 0, 0
    ans = 0
    while l < r:
        Lmax = max(Lmax, height[l])
        Rmax = max(Rmax, height[r])
        if Lmax <= Rmax:
            ans += Lmax - height[l]   # >=0，因为 Lmax 是到目前为止左侧最高
            l += 1
        else:
            ans += Rmax - height[r]
            r -= 1
    return ans
