t = int(input())
for _ in range(t):
    n,k1 = input().split()
    k = int(k1)
    stack = []
    for ch0 in n:
        ch = int(ch0)
        while stack and ch<stack[-1] and k:
            stack.pop()
            k-=1
        stack.append(ch)
    while k>0:
        stack.pop()
        k-=1
    print(''.join(str(x) for x in stack))
