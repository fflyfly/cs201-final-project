from typing import Optional,List
from collections import deque



class TreeNode:
    def __init__(self, val=0, left=None, right=None):
        self.val = val
        self.left = left
        self.right = right
class Solution:
    def rightSideView(self, root: Optional[TreeNode]) -> List[int]:
        ans = []
        if not root:
            return ans
        q = deque()
        q.append((root,0))
        nowc = 0
        nowval = 0
        while q:
            tmp,tmpnum = q.popleft()
            if tmpnum>nowc:#into next ceiling
                nowc = tmpnum
                ans.append(nowval)
            nowval = tmp.val
            if tmp.left:
                q.append((tmp.left,tmpnum+1))
            if tmp.right:
                q.append((tmp.right,tmpnum+1))
        ans.append(nowval)
        return ans
a = Solution()
R = TreeNode(1)
R.left = TreeNode(2)
R.left.right = TreeNode(5)
R.right = TreeNode(3)
print(a.rightSideView(R))

