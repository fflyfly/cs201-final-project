from typing import List
from collections import deque
class Solution:
    def snakesAndLadders(self, board: List[List[int]]) -> int:
        n = len(board[0])
        used = [[False]*n for _ in range(n)]


        def findpos(num):
            num -= 1
            row = n - 1 - num // n
            col = num % n
            if (num // n) % 2 == 1:  # 奇数行（从0开始）需要反转列
                col = n - 1 - col
            return row, col
        print(findpos(9))
        move = [1,2,3,4,5,6]
        q = deque()
        q.append((1,0))

        while q:
            tmpnum,tmpstep = q.popleft()
            if tmpstep>n*n:
                break
            for d in move:
                nxtnum =tmpnum+d
                nxtx,nxty = findpos(nxtnum)
                #print(f"d={d},nxtstep={tmpstep+1},nxtnum={nxtnum},nxtx={nxtx},nxty={nxty}")
                if nxtnum==n*n:
                    return tmpstep+1
                elif nxtnum<n*n:

                    if board[nxtx][nxty]==-1  and not used[nxtx][nxty]:
                        used[nxtx][nxty] = True
                        q.append((nxtnum,tmpstep+1))
                    elif board[nxtx][nxty]!=-1:
                        nxtnum = board[nxtx][nxty]
                        nxtx,nxty = findpos(nxtnum)
                        #print(f"d={d},nxtstep={tmpstep + 1},nxtnum={nxtnum},nxtx={nxtx},nxty={nxty}")
                        if nxtnum==n*n:
                            return tmpstep+1
                        elif nxtnum < n * n and not used[nxtx][nxty]:
                            used[nxtx][nxty] = True
                            q.append((nxtnum,tmpstep+1))

        return -1
a= Solution()
b = [[-1,-1,-1,46,47,-1,-1,-1],[51,-1,-1,63,-1,31,21,-1],[-1,-1,26,-1,-1,38,-1,-1],[-1,-1,11,-1,14,23,56,57],[11,-1,-1,-1,49,36,-1,48],[-1,-1,-1,33,56,-1,57,21],[-1,-1,-1,-1,-1,-1,2,-1],[-1,-1,-1,8,3,-1,6,56]]
print(a.snakesAndLadders(b))