class TreeNode:
    def __init__(self, x):
        self.val = x
        self.left = None
        self.right = None

class Solution:
    def lowestCommonAncestor(self, root: 'TreeNode', p: 'TreeNode', q: 'TreeNode') -> 'TreeNode':

        if root == p:
            return p
        if root ==q:
            return q
        if not root.left:
            left_com = None
        else:
            left_com = self.lowestCommonAncestor(root.left,p,q)
        if not root.right:
            right_com = None
        else:
            right_com = self.lowestCommonAncestor(root.right,p,q)
        if left_com and not right_com:
            return left_com
        elif right_com and not left_com:
            return right_com
        if not left_com and not right_com:
            return None
        return root
