n = int(input())
nums = []
head = 0
for i in range(n):
    l,r = map(int,input().split())
    nums.append((l,r))
ans,tmp,leaves = 0,0,0
used = [False]*n
for i in range(n):
    l,r = nums[i][0],nums[i][1]
    if l==-1 and r==-1:
        leaves+=1
        continue
    if l!=-1:
        used[l] = True
    if r!=-1:
        used[r] = True
for i in range(n):
    if not used[i]:
        head = i
        break
def dfs(x):
    global ans,tmp
    l,r = nums[x]

    if l==-1 and r==-1:
        ans = max(ans,tmp)
        return
    if l!=-1:
        tmp+=1
        dfs(l)
        tmp-=1
    if r!=-1:
        tmp+=1
        dfs(r)
        tmp-=1
dfs(head)
print(ans,leaves)