def prim_matrix(graph, n, start=0):
    inf = float('inf')
    key = [inf] * n
    key[start] = 0
    visited = [False] * n
    parent = [-1] * n
    for _ in range(n):  # 这里用 n，不是 V
        u = -1# 1) 找到未访问点里 key 最小的 u
        min_key = inf
        for v in range(n):
            if not visited[v] and key[v] < min_key:
                min_key = key[v]
                u = v
        if u == -1:  # 剩余点都不可达 => 图不连通
            return None, None
        visited[u] = True
        for v in range(n):# 2) 用 u 更新其他点的 key
            w = graph[u][v]
            if not visited[v] and w < key[v]:
                key[v] = w
                parent[v] = u
    return sum(key), parent# -------- 构造邻接矩阵 --------
n = 5
inf = float('inf')
graph = [[inf]*n for _ in range(n)]
for i in range(n):
    graph[i][i] = 0
def add_undirected(u, v, w):
    graph[u][v] = min(graph[u][v], w)
    graph[v][u] = min(graph[v][u], w)
add_undirected(0, 1, 2)
add_undirected(0, 3, 6)
add_undirected(1, 2, 3)
add_undirected(1, 3, 8)
add_undirected(1, 4, 5)
add_undirected(2, 4, 7)
add_undirected(3, 4, 9)
total, parent = prim_matrix(graph, n, start=0)
if total is None:
    print("图不连通，没有 MST")
else:
    print("MST total weight =", total)  # 16
    for v in range(n): # 如果想打印 MST 的边（除了 start 之外，每个点 v 都由 parent[v] 连进来）
        if parent[v] != -1:
            print(parent[v], "-", v, "weight", graph[parent[v]][v])