from typing import List
class Solution:
    def generateParenthesis(self, n: int) -> List[str]:
        ans = []
        tmp = []
        def dfs(left,right):
            if left==n and right==n:
                ans.append(''.join(tmp))
                return
            if left == right:
                tmp.append('(')
                dfs(left+1,right)
                tmp.pop()
            elif left>right:
                tmp.append(')')
                dfs(left,right+1)
                tmp.pop()
                if left<n:
                    tmp.append('(')
                    dfs(left+1,right)
                    tmp.pop()
        dfs(0,0)
        return ans
a = Solution()
print(a.generateParenthesis(3))