def find_next_greater(nums):
    n = len(nums)
    res = [0] * n
    stack = []
    for i in range(n):
        while stack and nums[i] < nums[stack[-1]]:
            res[stack.pop()] = i
        stack.append(i)
    while stack:
        res[stack.pop()] = n
    return res

print(find_next_greater([4, 5, 2, 25]))