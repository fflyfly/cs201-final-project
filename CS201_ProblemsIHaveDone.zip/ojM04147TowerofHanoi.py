lst = list(input().split())
n = int(lst[0])
lst = lst[1:]
def hanoi(num,from1,to1,by):
    if num==1:
        print(f"1:{from1}->{to1}")
    else:
        hanoi(num-1,from1,by,to1)
        print(f"{num}:{from1}->{to1}")
        hanoi(num - 1, by, to1,from1)
hanoi(n,lst[0],lst[2],lst[1])