from typing import List
class Solution:
    def dailyTemperatures(self, temperatures: List[int]) -> List[int]:
        def find_next_greater(nums):
            n = len(nums)
            res = [0] * n
            stack = []
            for i in range(n):
                while stack and nums[i] > nums[stack[-1]]:
                    res[stack.pop()] = i
                stack.append(i)
            while stack:
                res[stack.pop()] = n
            return res
        res = find_next_greater(temperatures)
        n = len(temperatures)
        ans = []
        for i,ch in enumerate(temperatures):
            if res[i]==n:
                ans.append(0)
            else:
                ans.append(res[i]-i)
        return ans
a = Solution()
print(a.dailyTemperatures([73,74,75,71,69,72,76,73]))