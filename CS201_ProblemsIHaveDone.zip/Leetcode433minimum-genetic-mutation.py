from typing import List
from collections import deque
class Solution:
    def minMutation(self, startGene: str, endGene: str, bank: List[str]) -> int:
        if endGene not in bank:
            return -1
        dic = {}
        for i,ch in enumerate(bank):
            for j in range(8):
                tab = ch[:j]+'*'+ch[j+1:]
                #print(tab)
                if tab not in dic:
                    dic[tab] = [ch]
                else:
                    dic[tab].append(ch)
        #print(dic)
        q = deque()
        q.append((startGene,0))
        used = set()
        while q:
            tmp,nownum = q.popleft()
            if tmp==endGene:
                return nownum
            for j in range(8):
                nowtab = tmp[:j]+'*'+tmp[j+1:]
                if nowtab in used or nowtab not in dic.keys():
                    continue
                for nxt in dic[nowtab]:
                    if nxt != tmp:
                        q.append((nxt,nownum+1))
                used.add(nowtab)
        return -1

a = Solution()
print(a.minMutation(startGene = "AAAAACCC", endGene = "AACCCCCC", bank = ["AAAACCCC","AAACCCCC","AACCCCCC"]))