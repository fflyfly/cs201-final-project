n,m = map(int,input().split())
M = []
for _ in range(n):
    M.append(list(input().split()))
move = [(-1,0),(1,0),(0,1),(0,-1)]
def isin(x,y):
    return 0<=x<=n-1 and 0<=y<=m-1
def dfs(x,y):
    for dx,dy in move:
        nx,ny = x+dx,y+dy
        if isin(nx,ny) and M[nx][ny]=='1':
            M[nx][ny]='2'
            dfs(nx,ny)
for i in range(n):
    for j in range(m):
        if (i==0 or i==n-1 or j==0 or j==m-1) and M[i][j]=='1':
            M[i][j]='2'
            dfs(i,j)
for i in range(n):
    for j in range(m):
        if M[i][j]=='2':
            M[i][j] = '1'
        else:
            M[i][j] = '0'
for i in range(n):
    print(' '.join(M[i]))