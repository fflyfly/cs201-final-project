import re
import sys

def validate_email(line):
    if line.find('@')!=line.rfind('@') or line.find('@')==-1 or line.find('@')==0 or line.rfind('@')==len(line)-1 or line.find('.')==0 or line.rfind('.')==len(line)-1:
        return False
    if line.rfind('.')>line.find('@') and line[line.find('@')+1]!='.' and line[line.find('@')-1]!='.':
        return True
    return False

for line in sys.stdin:
    line = line.strip()
    if validate_email(line):
        print("YES")
    else:
        print("NO")