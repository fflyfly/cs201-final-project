from bisect import bisect_right
def able(citations,x):
    cnt = sum(1 for _ in citations if _ >=x)
    return cnt>=x
class Solution(object):
    def hIndex(self, citations):
        h=0
        citations.sort()
        left = 0
        right = len(citations)
        if able(citations,right):
            return right
        middle = (left+right)//2
        while left<right-1:
            if able(citations,middle):
                left = middle
                middle = middle = (left+right)//2
            else:
                right = middle
                middle = middle = (left+right)//2
        return left
s = Solution()
print(s.hIndex([1,3,1]))

