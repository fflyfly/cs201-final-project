from collections import deque


class Node:
    def __init__(self,s):
        self.name = s
        self.bro = []
        self.num = -1
        self.sequence = []
    def check_and_connect(self,other:'Node'):
        cnt = 0
        for i in range(4):
            if self.name[i]!=other.name[i]:
                cnt+=1
        if cnt==1:
            self.bro.append(other)
            other.bro.append(self)
class Graph:
    def __init__(self,x):
        self.num = x
        self.nodes = []
    def insert(self,s):
        self.nodes.append(Node(s))
        for i in range(len(self.nodes)-1):
            self.nodes[-1].check_and_connect(self.nodes[i])
n = int(input())
g = Graph(n)
for _ in range(n):
    word = input()
    g.insert(word)
start = Node('x')
st,ed = input().split()
ans = []
for ch in g.nodes:
    if ch.name==st:
        start = ch
        start.num = 0
        start.sequence = [start.name]
q = deque()
q.append(start)
while q:
    tmp = q.popleft()
    now_s = tmp.sequence[:]
    flag = False
    for ch in tmp.bro:
        if ch.num==-1:
            ch.num = tmp.num+1
            this_s = now_s+[ch.name]
            ch.sequence = this_s
            if ch.name==ed:
                ans = ch.sequence
                flag = True
                break
            q.append(ch)
    if flag:
        break
if ans:
    print(' '.join(ans))
else:
    print("NO")