from collections import deque
n,m = map(int,input().split())
a = list(map(int,input().split()))
lst = []
q = deque()
for i in range(n):
    q.append((0,i))
while q:
    now,num = q.popleft()
    if not q:
        print(num+1)
        break
    now+=m
    if now<a[num]:
        q.append((now,num))