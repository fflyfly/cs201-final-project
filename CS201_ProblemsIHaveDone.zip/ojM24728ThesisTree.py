s = int(input())
class TreeNode:
    def __init__(self,val,sons = []):
        self.val = val
        self.sons = sons
stack = []
operator = []
for ch in s:
    if ch == '(':
        operator.append(ch)