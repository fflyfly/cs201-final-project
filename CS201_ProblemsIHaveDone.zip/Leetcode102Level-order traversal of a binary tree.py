# Definition for a binary tree node.
from typing import List,Optional
from collections import deque
class TreeNode:
    def __init__(self, val=0, left=None, right=None):
        self.val = val
        self.left = left
        self.right = right
class Solution:
    def levelOrder(self, root: Optional[TreeNode]) -> List[List[int]]:
        if not root:
            return []
        ans :List[List[int]] = []
        tmp: List[int] = []
        nownum = 0
        q = deque()
        q.append((root,0))
        while q:
            p,num = q.popleft()
            if num>nownum:
                nownum = num
                ans.append(tmp)
                tmp = []
            tmp.append(p.val)
            if p.left:
                q.append((p.left,num+1))
            if p.right:
                q.append((p.right,num+1))
        ans.append(tmp)
        return ans


