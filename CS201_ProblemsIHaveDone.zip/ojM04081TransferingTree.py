tmp = 0
m = 0
s = input()
l = len(s)
p,b = 0,0#p是当前二叉树中的高度，b是左边有几个兄弟
for ch in s:
    if ch =='d':
        tmp+=1
        b+=1
        m = max(m,tmp)
    else:
        tmp-=1

