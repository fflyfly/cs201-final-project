from collections import deque

n = int(input())
grps = []
members_to_grps = {}
for i in range(n):
    members = input().split()
    for m in members:
        members_to_grps[m] = i
q = deque()
p = {}
while True:
    s = input()
    if s=="STOP":
        break
    elif s!="DEQUEUE":
        no,x = s.split()
        ingrp = False
        if x in members_to_grps:
            if members_to_grps[x] in p:
                p[members_to_grps[x]].append(x)
            else:
                p[members_to_grps[x]] = deque([x])
                q.append(members_to_grps[x])
        else:
            q.append(x)

    else:
        if type(q[0])==str:
            print(q.popleft())
        else:
            num = q[0]
            print(p[num].popleft())
            if not p[num]:
                q.popleft()
                del(p[num])