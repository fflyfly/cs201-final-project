def binary_search_least_upper_bound(small, large):
    left, right = small, large + 1
    while left < right:
        mid = (left + right) // 2
        if valid(mid):
            left = mid + 1
        else:
            right = mid
    return right - 1
a = [1,2,3,4,4,5,6,7]
target = 4
def valid(i):
    global target
    return a[i]<=target
print(binary_search_least_upper_bound(0,len(a)-1))