str1 = input().strip()
Vowels = ['A','E','I','O','U','Y']
i=0
ln = len(str1)
str1 = str1.lower()
while True:

    if i==len(str1):
        break
    if str1[i].upper() in Vowels:
        str1 = str1[:i]+str1[i+1:]
        ln-=1
    else:
        str1 = str1[:i]+"."+str1[i:]
        i+=2
print(str1)