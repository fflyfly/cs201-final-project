n = int(input())
import heapq
lst = []
for _ in range(n):
    s = list(input().split())
    if len(s)==2:
        heapq.heappush(lst,int(s[1]))
    else:
        print(heapq.heappop(lst))


