import heapq

n,k = map(int,input().split())
a,b = [],[0]*(n+1)

for i in range(1,n+1):
    ai,b[i] = map(int,input().split())
    heapq.heappush(a,(-ai,i))
maxi = 0
ans = 0
for _ in range(k):
    nowcow = heapq.heappop(a)
    nowvote = b[nowcow[1]]
    if nowvote>maxi:
        maxi = nowvote
        ans = nowcow[1]
print(ans)