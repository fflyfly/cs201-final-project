from bisect import bisect_right
class Solution(object):
    def maximumBeauty(self, items, queries):
        """
        :type items: List[List[int]]
        :type queries: List[int]
        :rtype: List[int]
        """
        ans = []
        items1 = sorted(items, key=lambda x: (x[0]))
        prices = [q for q, _ in items1]
        pref = []
        best = 0
        for u in items1:
            best = max(best,u[1])
            pref.append(best)
        for i in queries:
            idx = bisect_right(prices,i)-1
            ans.append(0 if idx<0 else pref[idx])
        return ans

s = Solution()
print(s.maximumBeauty([[1,2],[3,2],[2,4],[5,6],[3,5]],[1,2,3,4,5,6]))