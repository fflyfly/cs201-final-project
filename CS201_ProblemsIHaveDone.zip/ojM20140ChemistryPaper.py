s = input().strip()
stack = []
nowstr = ""
nownum = 0
for ch in s:
    if ch=='[':
        stack.append((nowstr,nownum))#nownum是更大一级[]的倍数
        nowstr = ""
        nownum = 0
    elif ch==']':
        prestr,prenum = stack.pop()
        nowstr = prestr+nownum*nowstr
        nownum = prenum
    elif ch.isdigit():
        nownum = nownum*10+int(ch)
    else:
        nowstr = nowstr+ch

print(nowstr)