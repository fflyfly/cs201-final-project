n = int(input())
#123
#1 12 1
ans = [0]*(n+1)
for i in range(n+1):
    if i==1 or i==0:
        ans[i]=1
    else:
        for j in range(i):
            ans[i]+=ans[j]*ans[i-j-1]
print(ans[n])