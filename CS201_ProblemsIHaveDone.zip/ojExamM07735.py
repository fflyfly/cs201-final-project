import sys
import heapq
from collections import defaultdict, deque

input = sys.stdin.readline
INF = 10**18

def build_graph(n, edges, directed=True):
    """
    edges: [(u, v, w), ...]
    directed=True 表示有向图；False 表示无向图（自动加反向边）
    """
    g = [[] for _ in range(n + 1)]  # 1..n，若你是 0..n-1 就改成 n
    for u, v, w, t in edges:
        g[u].append((v, w,t))
        if not directed:
            g[v].append((u, w,t))
    return g

def dijkstra(n, g, s,k):
    """
    返回:
      dist[i]  : s->i 最短距离（不可达 INF）
      parent[i]: 最短路树的父节点，用于还原路径；s 的 parent[s]=-1
    """
    dist = [[INF] * (k + 1) for _ in range(n+1)]
    cost = [INF] * (n+1)
    dist[s][0] = 0
    pq = [(0,0, s)]  # (dist,cost, node)

    while pq:
        d,c, u = heapq.heappop(pq)
        if d != dist[u][c]:
            continue
        for v, w,t in g[u]:
            nd = d + w
            nc = c+t

            if nc<=k and nd < dist[v][nc]:
                dist[v][nc] = nd
                #print((nd,nc,v))
                heapq.heappush(pq, (nd,nc, v))
                #print("heapq:",pq)
    return dist
k = int(input())
n = int(input())
r = int(input())
edges = []
cost = []
for _ in range(r):
    s,d,l,t = map(int,input().split())
    edges.append((s,d,l,t))
g = build_graph(n,edges,directed=True)
s,t = 1,n
dist= dijkstra(n,g,s,k)
if min(dist[n]) < INF//2:
    print(min(dist[n]))
else:
    print(-1)