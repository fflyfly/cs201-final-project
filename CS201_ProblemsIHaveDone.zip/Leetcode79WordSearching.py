from typing import List
class Solution:
    def exist(self, board: List[List[str]], word: str) -> bool:
        row = len(board)
        col = len(board[0])
        step = 0
        move = [(-1,0),(0,1),(1,0),(0,-1)]
        used = [[False]*col for _ in range(row)]
        def isin(x,y):
            return 0<=x<row and 0<=y<col
        def dfs(x,y):
            nonlocal step
            print(step)
            if step == len(word):
                return True
            for ch in move:
                nx = x+ch[0]
                ny = y+ch[1]
                if isin(nx,ny) and board[nx][ny]==word[step] and not used[nx][ny]:
                    used[nx][ny] = True
                    step+=1
                    if dfs(nx,ny):
                        return True
                    step-=1
                    used[nx][ny] = False
            return False

        for i in range(row):
            for j in range(col):
                if board[i][j]==word[step] and not used[i][j]:
                    used[i][j] = True
                    step+=1
                    if dfs(i,j):
                        return True
                    step-=1
                    used[i][j] = False
        return False

a = Solution()
board  = [['A','B','C','E'],['S','F','C','S'],['A','D','E','E']]
word = "ABCCED"
print(a.exist(board,word))