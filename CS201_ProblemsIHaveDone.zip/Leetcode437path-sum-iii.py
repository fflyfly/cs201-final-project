from typing import Optional
class TreeNode:
    def __init__(self, val=0, left=None, right=None):
        self.val = val
        self.left = left
        self.right = right
class Solution:
    def pathSum(self, root: Optional[TreeNode], targetSum: int) -> int:
        self.ans = 0
        def dfs(begin:Optional[TreeNode],sums:list):
            tmp = []
            for s in sums:
                if begin.val+s==targetSum:
                    #print(f"sum = {s},val = {begin.val}")
                    self.ans+=1
                tmp.append(s + begin.val)
            if begin.val == targetSum:
                self.ans+=1
            tmp.append(begin.val)
            if begin.left:
                dfs(begin.left,tmp)
            if begin.right:
                dfs(begin.right,tmp)
        if root:
            dfs(root,[])
        return self.ans
T = TreeNode(10)
T.left = TreeNode(5)
T.left.left = TreeNode(3)
T.left.left.left = TreeNode(3)
T.left.left.right = TreeNode(-2)
T.left.right = TreeNode(2)
T.left.right.right = TreeNode(1)
T.right = TreeNode(-3)
T.right.right = TreeNode(11)
a = Solution()
print(a.pathSum(T,8))