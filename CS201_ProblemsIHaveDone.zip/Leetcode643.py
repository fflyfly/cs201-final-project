from typing import List
class Solution:
    def findMaxAverage(self, nums: List[int], k: int) -> float:
        n = len(nums)
        right = 0
        average = 0
        for left in range(n):
            # 做与left有关的操作
            average
            while right < n and (与right有关的某一条件):
                # 做与right有关的操作
                right += 1
            # 做一些操作，如增加计数等，比如n - right + 1