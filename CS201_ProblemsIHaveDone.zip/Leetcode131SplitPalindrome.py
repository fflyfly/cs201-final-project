from typing import List
from collections import deque
class Solution:
    def isp(self,s:str)-> bool:
        if len(s)==0 or len(s)==1:
            return True
        i=0
        j = len(s)-1
        while i<j:
            if s[i]!=s[j]:
                return False
            i+=1
            j-=1
        return True
    def partition(self, s: str) -> List[List[str]]:
        l = len(s)
        if len(s)==1:
            return [[s]]

        ans :List[List[str]] = []
        tmp = []
        can = []#i<=x<j
        i,j = 0,0
        for i in range(l):#0,1,2,l=3
            for j in range(i,l):
                if self.isp(s[i:j+1]):
                    can.append((i,j))
        can.sort(key = lambda x:(x[0],x[1]))
        #print(can)
        def dfs(x):
            #print(f"x={x}")
            nonlocal l,ans,tmp,can
            if x==l:
                ans.append(tmp[:])
                return

            for i in range(x,l):
                if (x,i) in can:
                    #print((x,i))
                    tmp.append(s[x:i+1])
                    dfs(i+1)
                    tmp.pop()

        dfs(0)
        return ans

a = Solution()
print(a.partition("aab"))