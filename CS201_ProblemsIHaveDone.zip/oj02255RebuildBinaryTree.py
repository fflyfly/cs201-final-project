def op(p,m):
    if not p:
        return ""
    r = p[0]
    idx = m.find(r)
    mleft = m[:idx]
    mright = m[idx+1:]
    lenleft = len(mleft)
    pleft,pright = p[1:1+lenleft],p[1+lenleft:]

    return op(pleft,mleft) + op(pright,mright) + r
while True:
    try:
        s = input()
        pre,mid = s.split()
        ans = op(pre,mid)
        print(ans)


    except EOFError:
        break
