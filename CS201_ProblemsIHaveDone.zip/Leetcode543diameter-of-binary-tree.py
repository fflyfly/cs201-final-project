from typing import Optional
class TreeNode:
    def __init__(self, val=0, left=None, right=None):
        self.val = val
        self.left = left
        self.right = right
class Solution:
    def diameterOfBinaryTree(self, root: Optional[TreeNode]) -> int:
        self.ans = 1
        def depth(root:Optional[TreeNode]):
            if not root:
                return 0
            ld = depth(root.left)
            rd = depth(root.right)
            self.ans = max(self.ans,ld+rd+1)
            return max(ld,rd)+1
        depth(root)
        return self.ans-1