m= int(input())
n = int(input())
ca = []
used = []
for i in range(m):
    ca.append(list(map(int,input().split())))
    used.append([False]*n)
maxi = 0
cnt = 0
tmp = 0
def isin(x,y):
    return 0<=x<m and 0 <= y < n
dx = [0,-1,0,1]
dy = [-1,0,1,0]
def dfs(x,y):
    global tmp
    tmp += 1
    for i in range(4):
        nx = x+dx[i]
        ny = y+dy[i]

        if isin(nx,ny) and not used[nx][ny] and not ca[x][y] & 1<<i:
            used[nx][ny] = True
            dfs(nx,ny)
for i in range(m):
    for j in range(n):
        if not used[i][j]:
            #print(i,j)
            used[i][j] = True
            tmp = 0
            dfs(i,j)
            #print(used)
            maxi = max(maxi,tmp)
            cnt+=1
            #print(cnt)
print(cnt)
print(maxi)