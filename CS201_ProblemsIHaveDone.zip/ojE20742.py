a=[]
a.append(0)
a.append(1)
a.append(1)
n=int(input().strip())
for i in range(3,n+1):
    tmp = sum(a)
    a[0]=a[1]
    a[1]=a[2]
    a[2]=tmp
print(a[2])