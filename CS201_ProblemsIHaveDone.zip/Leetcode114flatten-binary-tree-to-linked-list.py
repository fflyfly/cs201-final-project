# Definition for a binary tree node.
from typing import Optional
from collections import deque
class TreeNode:
    def __init__(self, val=0, left=None, right=None):
        self.val = val
        self.left = left
        self.right = right
class Solution:
    def flatten(self, root: Optional[TreeNode]) -> None:
        """
        Do not return anything, modify root in-place instead.
        """
        if root == None:
            return
        q = deque()
        q.append(root)
        def dfs(node):
            if node.left:
                q.append(node.left)
                dfs(node.left)

            if node.right:
                q.append(node.right)
                dfs(node.right)
        dfs(root)
        now = q.popleft()
        while q:
            next = q.popleft()
            now.right = next
            now.left = None
            now = now.right
a = Solution()
t = TreeNode(1,TreeNode(2,TreeNode(3)),TreeNode(4))
a.flatten(t)
print(t.right.left)