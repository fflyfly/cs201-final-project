from typing import List
import heapq
class Solution:
    def lastStoneWeight(self, stones: List[int]) -> int:
        s = list(map(lambda x:x*(-1),stones))

        heapq.heapify(s)
        while len(s)>1:
            a = heapq.heappop(s)
            b = heapq.heappop(s)
            if a==b:
                continue
            else:
                heapq.heappush(s,-abs(a-b))
        if not s:
            return 0
        else:
            return -s[0]