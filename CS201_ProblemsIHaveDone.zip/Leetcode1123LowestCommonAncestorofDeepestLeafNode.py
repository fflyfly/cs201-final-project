# Definition for a binary tree node.
from typing import Optional
from collections import deque
class TreeNode:
    def __init__(self, val=0, left=None, right=None):
        self.val = val
        self.left = left
        self.right = right
class Solution:
    def lcaDeepestLeaves(self, root: Optional[TreeNode]) -> Optional[TreeNode]:
        def dfs(node:Optional[TreeNode])->tuple[Optional[TreeNode],int]:
            if not node:
                return (None,0)
            lnode,lnum = dfs(node.left)
            rnode,rnum = dfs(node.right)
            if lnum>rnum:
                return (lnode,lnum+1)
            elif lnum<rnum:
                return (rnode,rnum+1)
            else:
                return (node,lnum+1)
        return dfs(root)[0]

a = Solution()
print(a.lcaDeepestLeaves(TreeNode(0,TreeNode(1),TreeNode(2))))