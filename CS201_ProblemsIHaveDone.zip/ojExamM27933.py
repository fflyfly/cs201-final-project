n = int(input())
stack = []
result = []
ans = 0
for _ in range(2*n):
    order = list(input().split())
    if len(order) == 2:
        stack.append(int(order[1]))
    else:
        if (result and stack[-1] == result[-1]+1) or (not result and stack[-1]==1):
            result.append(stack.pop())
        else:
            stack.sort(reverse=True)
            ans+=1
            result.append(stack.pop())
print(ans)