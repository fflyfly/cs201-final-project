n = int(input())
graph = {}
for _ in range(n-1):
    s,t = map(int,input().split())
    if s not in graph:
        graph[s] = []
    if t not in graph:
        graph[t] = []
    graph[s].append(t)
    graph[t].append(s)
cannot = list(map(int,input().split()))
used = [False]*n
cnt = 0
def dfs(x):
    global cnt
    for nxt in graph[x]:
        if not used[nxt] and nxt not in cannot:
            used[nxt] = True
            dfs(nxt)
            cnt+=1
cnt+=1
used[0] = True
dfs(0)
print(cnt)