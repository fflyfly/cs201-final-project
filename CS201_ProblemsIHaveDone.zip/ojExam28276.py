class DisjointSet:
    def __init__(self, k):
        self.parents = list(range(k))
        self.rank = [1] * k
    def find(self, x):
        if self.parents[x] != x:
            self.parents[x] = self.find(self.parents[x])
        return self.parents[x]
    def union(self, x, y):
        x_rep, y_rep = self.find(x), self.find(y)
        if x_rep == y_rep:
            return
        if self.rank[x_rep] < self.rank[y_rep]:
            self.parents[x_rep] = y_rep
        elif self.rank[x_rep] > self.rank[y_rep]:
            self.parents[y_rep] = x_rep
        else:
            self.parents[y_rep] = x_rep
            self.rank[x_rep] += 1
n = int(input())
d = DisjointSet(26)
cannot = []
for _ in range(n):
    s = input().strip()
    x1,x2 = s[0],s[3]
    y1,y2= ord(x1)-97,ord(x2)-97
    if s[1]=='=':
        for i in range(26):
            d.union(y1,y2)
    else:
        cannot.append((y1,y2))
flag = True
for x1,x2 in cannot:
    if d.find(x1)==d.find(x2):
        flag = False
        break
if flag:
    print("True")
else:
    print("False")
