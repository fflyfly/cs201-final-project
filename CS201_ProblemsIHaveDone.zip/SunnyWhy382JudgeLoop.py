
class Nodes:
    def __init__(self,num):
        self.val = num
        self.vs = set()
    def appendv(self,n):
        self.vs.add(n)
class Graph:
    def __init__(self,n):
        self.num = n
        self.nodes = [Nodes(i) for i in range(n)]
    def appendedge(self,s,e):
        self.nodes[s].appendv(e)
    def haveloop(self):
        start = 0
        used = []
        nowstart = 0
        def dfs(x):
            for ch in self.nodes[x].vs:
                #print(ch)
                if ch==nowstart:
                    return True
                if ch not in used:
                    used.append(ch)
                    if dfs(ch):
                        return True
                    used.pop()
        for i in range(n):
            used = [i]
            nowstart = i
            if dfs(i):
                return True
        return False

n,m = map(int,input().split())
g = Graph(n)
for _ in range(m):
    st,ed = map(int,input().split())
    g.appendedge(st,ed)
print("Yes" if g.haveloop() else "No")