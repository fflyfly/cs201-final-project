import math
class Add:
    def __init__(self,nums):
        a1=nums[0]
        b1=nums[1]
        a2=nums[2]
        b2=nums[3]
        self.ans1=a1*b2+b1*a2
        self.ans2=b1*b2
        gcd=math.gcd(self.ans1,self.ans2)
        self.ans1 /= gcd
        self.ans2 /= gcd
    def outpot(self):
        if self.ans1%self.ans2!=0:
            print(f"{self.ans1:.0f}/{self.ans2:.0f}")
        else:
            print(f"{self.ans1/self.ans2:.0f}")


nums = list(map(int,input().split()))
add1 = Add(nums)
add1.outpot()