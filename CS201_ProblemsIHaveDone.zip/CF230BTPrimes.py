import math
from math import isqrt

n = int(input())
lst = list(map(int,input().split()))
for num in lst:
    if num==0 or num==1:
        print("NO")
        continue
    flag = True
    t = isqrt(num)
    #print(t)
    if t*t!=num:
        print("NO")
        continue
    for i in range(2,t):
        if t%i==0:
            print("NO")
            flag = False
            break
    if flag:
        print("YES")
