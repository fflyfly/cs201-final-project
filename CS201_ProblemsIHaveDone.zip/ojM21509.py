import heapq
n = int(input())
s = list(map(int,input().split()))
left_max = []
right_min = []
for i in range(n):
    a = s[i]
    if i==0 or a<=-left_max[0]:
        heapq.heappush(left_max,-a)
    else:
        heapq.heappush(right_min,a)
    if len(left_max)>len(right_min)+1:
        heapq.heappush(right_min,-heapq.heappop(left_max))
    elif len(left_max)<len(right_min):
        heapq.heappush(left_max, -heapq.heappop(right_min))

    if i%2==0:
        print(-left_max[0])
