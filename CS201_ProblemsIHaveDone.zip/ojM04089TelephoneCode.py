t = int(input())
def able(x:str,y:str):
    if len(y)<len(x):
        x,y = y,x
    for i,ch in enumerate(x):
        if ch!=y[i]:
            return False
    return True
for _ in range(t):
    n = int(input())
    flag = 'YES'
    codes = []
    for __ in range(n):
        codes.append(input())
    codes.sort()
    for i in range(len(codes)-1):
        if able(codes[i],codes[i+1]):
            flag = 'NO'
            break
    print(flag)