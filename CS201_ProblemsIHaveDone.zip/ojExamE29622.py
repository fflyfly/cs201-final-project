from heapq import heappush, heappop
def prim(graph, n, start=0):
    visited = [False] * n
    visited[start] = True
    heap = []
    result = []
    for (to, w) in graph[start]:
        heappush(heap, (w, start, to))
    while heap and len(result) < n - 1:
        w, u, v = heappop(heap)
        if visited[v]:
            continue
        visited[v] = True
        result.append((w, u, v))
        for (to, w2) in graph[v]:
            if not visited[to]:
                heappush(heap, (w2, v, to))
    if len(result) != n - 1:
        return None  # 表示没有生成树（图不连通）
    return result
n,m = map(int,input().split())
graph = [[] for _ in range(n)]
def add_undirected(u, v, w):
    graph[u].append((v, w))
    graph[v].append((u, w))
for _ in range(m):
    u,v,w = map(int,input().split())
    add_undirected(u-1,v-1,w)
mst = prim(graph, n, start=0)
if mst is None:
    print("orz")
else:
    total = sum(w for w, u, v in mst)
    print(total)