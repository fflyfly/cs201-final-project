class DisjointSet:
    def __init__(self, k):
        self.parents = list(range(k))
        self.rank = [1] * k
    def find(self, x):
        if self.parents[x] != x:
            self.parents[x] = self.find(self.parents[x])
        return self.parents[x]
    def union(self, x, y):
        x_rep, y_rep = self.find(x), self.find(y)
        if x_rep == y_rep:
            return
        if self.rank[x_rep] < self.rank[y_rep]:
            self.parents[x_rep] = y_rep
        elif self.rank[x_rep] > self.rank[y_rep]:
            self.parents[y_rep] = x_rep
        else:
            self.parents[y_rep] = x_rep
            self.rank[x_rep] += 1
n,m = map(int,input().split())
cost = list(map(int,input().split()))#此处所有人的实际编号都是输入编号-1
d = DisjointSet(n)
for _ in range(m):
    a,b = map(int,input().split())
    d.union(a-1,b-1)
ultparents = []
for i in range(n):
    ultparents.append(d.find(i))
parent_to_son = {}
for i,ch in enumerate(ultparents):
    if ch not in parent_to_son:
        parent_to_son[ch] = []
    parent_to_son[ch].append(cost[i])
ans = 0
for idx in parent_to_son.keys():
    ans+=min(parent_to_son[idx])
print(ans)