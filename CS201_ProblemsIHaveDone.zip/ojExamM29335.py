s = input().strip()
if s[0] == '/':
    s = s[1:]
if s[-1]=='/':
    s = s[:-1]
s = list(s.split('/'))
stack = []

for ch in s:
    if ch=='.' or ch =='':
        continue
    if ch=='..':
        if stack:
            stack.pop()
    else:
        stack.append(ch)
ans = '/'+'/'.join(stack)
print(ans)