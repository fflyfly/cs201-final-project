# Definition for a binary tree node.
from typing import Optional,List
class TreeNode:
    def __init__(self, val=0, left=None, right=None):
        self.val = val
        self.left = left
        self.right = right
class Solution:
    def sortedArrayToBST(self, nums: List[int]) -> Optional[TreeNode]:
        def build(l:int,r:int)->Optional[TreeNode]:
            if l>r:
                return None
            mid = (l+r)//2
            root = TreeNode(nums[mid])
            left = build(l,mid-1)
            root.left = left
            right = build(mid+1,r)
            root.right = right
            return root
        return build(0,len(nums)-1)
a = Solution()
print(a.sortedArrayToBST([-10,-3,0,5,9]).left.right.val)