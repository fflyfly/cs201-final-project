from collections import defaultdict
class Solution(object):

    def groupAnagrams(self,strs):
        now = defaultdict(list)
        for ch in strs:
            tmp = tuple(sorted(ch))
            now[tmp].append(ch)
        return list(now.values())


a = Solution()
print(a.groupAnagrams(["eat", "eat","tea", "tan", "ate", "nat", "bat"]))