class pos:
    def __init__(self,x,y,num):
        self.x = x
        self.y = y
        self.num = num
    def show(self):
        print(self.x,self.y,self.num)
    def able(self,x1,y1,d):
        return abs(x1-self.x)<=d and abs(y1-self.y)<=d
d = int(input())
n = int(input())
p = []
for _ in range(n):
    x,y,num = map(int,input().split())
    p.append(pos(x,y,num))
ans = 0
maxi = 0
for i in range(1025):
    for j in range(1025):
        tmp=0
        for ch in p:
            if ch.able(i,j,d):
                tmp+=ch.num
        if tmp==maxi:
            ans+=1
        elif tmp>maxi:
            ans = 1
            maxi = tmp
print(ans,maxi)

