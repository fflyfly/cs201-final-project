m,n,p,q = map(int,input().split())
M = [list(map(int,input().split())) for _ in range(m)]
C = [list(map(int,input().split())) for _ in range(p)]
ans = []
m1 = m+1-p
n1 = n+1-q
for _ in range(m1):
    ans.append([0]*(n1))
for i in range(m1):
    for j in range(n1):
        for k in range(p):
            for l in range(q):
                ans[i][j]+=C[k][l]*M[i+k][j+l]
for ch in ans:
    print(' '.join(map(str,ch)))