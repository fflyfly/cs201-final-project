from collections import deque
class TreeNode:
    def __init__(self,val = None,childnum = 0):
        self.val = val
        self.child = []
        self.childnum = childnum

n = int(input())
forests = []
ans = []


def out(root: TreeNode):
    if root.child != []:
        for ch in root.child:
            out(ch)
    ans.append(root.val)
for _ in range(n):
    s = list(input().split())
    #print(s)
    i=0
    q = []
    while i<len(s):
        val,leave = s[i],int(s[i+1])
        q.append((val,leave))
        i+=2
    #q=[(C,3),(E,3),...]
    nds = q[:]
    rval,rleave = q[0]
    root = TreeNode(val=rval,childnum=rleave)
    q1 = deque([root])
    nxt = 1
    while q1:
        nownode = q1.popleft()
        #print(nownode.childnum)
        for i in range(nownode.childnum):
            tmp = q[nxt]
            tmpnode =TreeNode(val=tmp[0],childnum=tmp[1])
            nownode.child.append(tmpnode)
            q1.append(tmpnode)
            nxt+=1
    #for j in root.child:
    #    print(j.val)
    out(root)
print(' '.join(ans))


