from typing import List
class Solution:
    def nextGreaterElements(self, nums: List[int]) -> List[int]:
        def find_next_greater(nums):
            n = len(nums)
            res = [0] * n
            stack = []
            for i in range(n):
                while stack and nums[i] > nums[stack[-1]]:
                    res[stack.pop()] = i
                stack.append(i)
            while stack:
                res[stack.pop()] = n
            return res
        nums2 = nums+nums
        n2 = 2*len(nums)
        res = find_next_greater(nums2)
        #print(nums2)
        ans = []
        for i in range(len(nums)):
            if res[i]==n2:
                ans.append(-1)
            else:
                ans.append(nums2[res[i]])
        return ans
a = Solution()
print(a.nextGreaterElements([1,2,3,4,3]))