class M:
    def __init__(self,r,c,L):
        self.r = r
        self.c = c
        self.MM = L
    def show(self):
        for ch in self.MM:
            print(' '.join(map(str,ch)))
    def __add__(self,other):
        rt = self.MM
        for i in range(self.r):
            for j in range(self.c):
                rt[i][j]+=other.MM[i][j]
        return M(self.r,self.c,rt)
    def __matmul__(self, other):
        rt = []
        r = self.r
        c = other.c
        for i in range(r):
            rt.append([0]*c)
        for i in range(r):
            for j in range(c):
                for k in range(self.c):
                    rt[i][j]+=self.MM[i][k]*other.MM[k][j]
        return M(r,c,rt)

ra,ca = map(int,input().strip().split())
a = [list(map(int,input().split())) for _ in range(ra)]
rb,cb = map(int,input().strip().split())
b = [list(map(int,input().split())) for _ in range(rb)]
rc,cc = map(int,input().strip().split())
c = [list(map(int,input().split())) for _ in range(rc)]
#print(ra,ca,rb,cb,rc,cc)
if ca!=rb or ra!=rc or cb!=cc:
    print("Error!")
else:
    A = M(ra,ca,a)
    B = M(rb,cb,b)
    C = M(rc,cc,c)
    #A.show()
    #print("-----")
    AB = A@B
    ABC = AB +C
    ABC.show()

