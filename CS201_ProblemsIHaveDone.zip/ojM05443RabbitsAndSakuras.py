import sys
import heapq
from collections import defaultdict, deque

input = sys.stdin.readline
INF = 10**18

def build_graph(n, edges, directed=True):
    """
    edges: [(u, v, w), ...]
    directed=True 表示有向图；False 表示无向图（自动加反向边）
    """
    g = [[] for _ in range(n + 1)]  # 1..n，若你是 0..n-1 就改成 n
    for u, v, w in edges:
        g[u].append((v, w))
        if not directed:
            g[v].append((u, w))
    return g

def dijkstra(n, g, s):
    """
    返回:
      dist[i]  : s->i 最短距离（不可达 INF）
      parent[i]: 最短路树的父节点，用于还原路径；s 的 parent[s]=-1
    """
    dist = [INF] * (n + 1)
    parent = [-1] * (n + 1)
    dist[s] = 0
    pq = [(0, s)]  # (dist, node)

    while pq:
        d, u = heapq.heappop(pq)
        if d != dist[u]:
            continue
        for v, w in g[u]:
            nd = d + w
            if nd < dist[v]:
                dist[v] = nd
                parent[v] = u
                heapq.heappush(pq, (nd, v))
    return dist, parent

def restore_path(parent, s, t):
    """还原 s->t 的路径（节点序列）。不可达则返回 []"""
    path = []
    cur = t
    while cur != -1:
        path.append(cur)
        if cur == s:
            break
        cur = parent[cur]
    if path[-1] != s:
        return []
    path.reverse()
    return path

P = int(input())
name_to_num = {}
num_to_name = {}
for i in range(P):
    name = input().strip()
    name_to_num[name] = i+1
    num_to_name[i+1] = name
#print(name_to_num)
Q = int(input())
edges = []
e = [defaultdict(int) for _ in range(P+1)]
for i in range(Q):
    s,t,val1 = input().split()
    val = int(val1)
    edges.append((name_to_num[s],name_to_num[t],val))
    e[name_to_num[s]][name_to_num[t]] = val
    e[name_to_num[t]][name_to_num[s]] = val
g = build_graph(P,edges,directed=False)
R = int(input())
ask = []
for i in range(R):
    st,ed = input().split()
    ask.append((name_to_num[st],name_to_num[ed]))
#print(ask)
for s,t in ask:
    dist,parent = dijkstra(P,g,s)
    path = restore_path(parent,s,t)
    #print(path)
    ans = []
    ans.append(str(num_to_name[s]))
    for j in range(1,len(path)):
        #print(j)
        ans.append('('+str(e[path[j-1]][path[j]])+')')
        ans.append(str(num_to_name[path[j]]))
    print('->'.join(ans))

