n,k = map(int,input().split())
woods = []
left = 1
for _ in range(n):
    woods.append(int(input()))
right = max(woods)#左边行右边不行
middle = (left+right)//2
def able(x):#x是一个长度
    global k,n
    cnt = 0
    for i in range(n):
        if woods[i]>=x:
            cnt+=(woods[i]//x)
    return cnt>=k
while left<right-1:
    if able(middle):
        left = middle
    else:
        right = middle
    middle = (left+right)//2
if k>sum(woods):
    left = 0
print(left)