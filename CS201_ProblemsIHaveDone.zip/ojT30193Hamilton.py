n,m,k,b = map(int,input().split())
must = {}
cannot = []
for _ in range(k):
    r,c,t = map(int,input().split())
    must[(r,c)] = t
for _ in range(b):
    x,y = map(int,input().split())
    cannot.append((x,y))
visited = [[False]*(m+1) for _ in range(n+1)]
def isin(x,y):
    return 1<=x<=n and 1<=y<=m
move = [(-1,0),(1,0),(0,1),(0,-1)]
ans = []
flag = False
def dfs(x,y,step):
    global flag
    if step == n*m-b:
        for ch in ans:
            print(f"{ch[0]} {ch[1]}")
        flag = True
        return True
    for dx,dy in move:
        nx,ny = x+dx,y+dy
        if isin(nx,ny) and not visited[nx][ny] and (nx,ny) not in cannot:
            if (nx,ny) in must and step+1!=must[(nx,ny)]:
                continue
            visited[nx][ny] = True
            ans.append((nx,ny))
            if dfs(nx,ny,step+1):
                return True
            ans.pop()
            visited[nx][ny] = False
dfs(1,1,1)
if not flag:
    print(-1)