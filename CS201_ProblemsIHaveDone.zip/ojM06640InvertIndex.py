N = int(input())
lst = []
for _ in range(N):
    lst.append(list(input().split())[1:])
M = int(input())
for _ in range(M):
    s = input().strip()
    ans = []
    for i,m in enumerate(lst):
        if s in m:
            ans.append(i+1)
    print(' '.join(map(str,ans)))