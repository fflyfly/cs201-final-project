from typing import List
class Solution:

    def nextGreaterElement(self, nums1: List[int], nums2: List[int]) -> List[int]:
        def find_next_greater(nums):
            n = len(nums)
            res = [0] * n
            stack = []
            for i in range(n):
                while stack and nums[i] > nums[stack[-1]]:
                    res[stack.pop()] = i
                stack.append(i)
            while stack:
                res[stack.pop()] = -1
            return res
        stack = find_next_greater(nums2)
        #print(stack)
        ans = []
        for i,ch in enumerate(nums1):
            idx = nums2.index(ch)
            if stack[idx]>=0:
                ans.append(nums2[stack[idx]])
            else:
                ans.append(-1)
        return ans


num1 = [2,4]
num2 = [1,2,3,4]
a = Solution()
print(a.nextGreaterElement(num1,num2))