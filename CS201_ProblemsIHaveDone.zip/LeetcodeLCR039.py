from typing import List
class Solution:
    def largestRectangleArea(self, heights: List[int]) -> int:
        def find_next_greater(nums):
            n = len(nums)
            res = [0] * n
            stack = []
            for i in range(n):
                while stack and nums[i] < nums[stack[-1]]:  # 变成<即为右边第一个更小数的索引
                    res[stack.pop()] = i
                stack.append(i)
            while stack:
                res[stack.pop()] = n
            return res

        def find_last_greater_on_left(nums):
            n = len(nums)
            res = [-1] * n
            stack = []  # 单调递减栈
            for i in range(n):
                while stack and nums[stack[-1]] >= nums[i]:  # 弹出所有小于等于当前元素的栈顶,改成>=就是左边最后一个小于其的
                    stack.pop()
                if stack:
                    res[i] = stack[-1]  # 如果栈不为空，栈顶就是左边最近大于当前元素的
                stack.append(i)  # 将当前索引入栈
            return res
        rightres = find_next_greater(heights)
        leftres = find_last_greater_on_left(heights)
        maxi = []
        #print(rightres)
        #print(leftres)
        for i in range(len(heights)):
            if i==0:
                maxi.append(heights[i]*(rightres[i]-i))
            elif i==len(heights)-1:
                maxi.append(heights[i]*(i-leftres[i]))
            else:
                maxi.append(heights[i]*(rightres[i]-leftres[i]-1))
        #print(maxi)
        return max(maxi)
a = Solution()
print(a.largestRectangleArea([2,4]))