import sys
dp = [[0]*55 for _ in range(55)]
for i in range(1,55):

    if i==1:
        dp[i][1] = 1
        for j in range(i + 1, 55):
            dp[i][j] = dp[i][i]
        continue
    dp[i][1]=1
    for j in range(2,i):
        dp[i][j] = dp[i][j-1]+dp[i-j][j]
    for j in range(i,55):
        dp[i][j] = dp[i][i-1]+1
for line in sys.stdin:
    line = line.strip()
    if not line:
        continue
    n = int(line)
    print(dp[n][n])
