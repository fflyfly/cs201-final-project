from typing import List
class Solution:
    def solveNQueens(self, n: int) -> List[List[str]]:
        tmp = []
        ans = []
        def able(i,j):
            for a,b  in enumerate(tmp):#tmp[a]=b：第[a+1]行第b个是Queen
                if abs(i-a-1)==abs(j-b):
                    return False
            return True
        def out():
            a = []
            for ch in tmp:
                line = ['.']*n
                line[ch-1] = 'Q'
                a.append(''.join(line))
            ans.append(a[:])
        def dfs(i):
            #print(f"i={i},tmp = {tmp}")
            if i==n+1:
                out()
                return
            for j in range(1,n+1):
                if able(i,j) and j not in tmp:
                    tmp.append(j)
                    dfs(i+1)
                    tmp.pop()
        dfs(1)
        return ans
a = Solution()
print(a.solveNQueens(8))