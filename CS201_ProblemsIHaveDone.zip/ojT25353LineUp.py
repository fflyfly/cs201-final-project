import sys
import bisect

class BIT:
    def __init__(self, n):
        self.n = n
        self.bit = [0] * (n + 1)
    def update(self, idx, val):
        n = self.n
        bit = self.bit
        while idx <= n:
            if val > bit[idx]:
                bit[idx] = val
            idx += idx & -idx
    def query(self, idx):
        res = 0
        bit = self.bit
        while idx > 0:
            if bit[idx] > res:
                res = bit[idx]
            idx -= idx & -idx
        return res

def main():
    data = sys.stdin.read().strip().split()
    if not data:
        return
    it = iter(data)
    N = int(next(it))
    D = int(next(it))
    h = [int(next(it)) for _ in range(N)]
    vals = sorted(set(h))
    M = len(vals)
    bitLow = BIT(M)
    bitHigh = BIT(M)
    layers = [0] * N
    buckets = [[] for _ in range(N+2)]   # 第 L 层同学的身高存 buckets[L]
    maxLayer = 0
    for i in range(N):
        hi = h[i]
        # hi 对应的离散下标（1-based）
        id_hi = bisect.bisect_left(vals,hi)+1

        # ---------- 查询 1：所有身高 < (hi - D) 的最大 layer ----------
        left_bound = hi-D
        # vals[0 .. pLow-1] < left_bound
        pLow = bisect.bisect_left(vals, left_bound)   # 0-based
        if pLow > 0:
            bestLow = bitLow.query(pLow)
        else:
            bestLow = 0
        right_bound = hi+D
        pHigh = bisect.bisect_right(vals, right_bound)  # 第一个 > right_bound 的位置(0-based)
        len_suffix = M-pHigh
        if len_suffix > 0:
            bestHigh = bitHigh.query(len_suffix)
        else:
            bestHigh = 0

        curLayer = max(bestLow, bestHigh)+1
        layers[i] = curLayer
        buckets[curLayer].append(hi)
        if curLayer > maxLayer:
            maxLayer = curLayer

        bitLow.update(id_hi,curLayer)
        rev_id = M-id_hi+1
        bitHigh.update(rev_id,curLayer)
    out = []
    for L in range(1, maxLayer + 1):
        buckets[L].sort()
        for x in buckets[L]:
            out.append(str(x))
    sys.stdout.write("\n".join(out))


if __name__ == "__main__":
    main()
