from typing import List
class Solution:
    def numIslands(self, grid: List[List[str]]) -> int:
        row = len(grid)
        col = len(grid[0])
        move = [(-1,0),(0,1),(1,0),(0,-1)]
        used = [[False]*col for _ in range(row)]
        cnt = 0
        def isin(x,y):
            nonlocal row,col
            return 0<=x<row and 0<=y<col
        def dfs(x,y):
            for ch in move:
                nx = x+ch[0]
                ny = y+ch[1]
                if isin(nx,ny) and grid[nx][ny]=='1' and not used[nx][ny]:
                    used[nx][ny] = True
                    dfs(nx,ny)
        for i in range(row):
            for j in range(col):
                if grid[i][j]=='1' and not used[i][j]:
                    used[i][j] = True
                    cnt+=1
                    dfs(i,j)
        return cnt

a= Solution()
grid = [
  ['1','1','0','0','0'],
  ['1','1','0','0','0'],
  ['0','0','1','0','0'],
  ['0','0','0','1','1']
]
print(a.numIslands(grid))