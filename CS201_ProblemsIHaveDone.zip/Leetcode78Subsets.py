class Solution(object):
    def subsets(self, nums):
        """
        :type nums: List[int]
        :rtype: List[List[int]]
        """
        ans = []
        tmp = []
        used = [False]*len(nums)
        def dfs(nums1):
            if not nums1:
                ans.append(tmp[:])
                return
            tmp.append(nums1[0])
            dfs(nums1[1:])
            tmp.pop()
            dfs(nums1[1:])

        dfs(nums)
        return ans


a = Solution()
print(a.subsets([1,2,3]))