s = input().strip()
std = "hello"
def comp(s1,std1):
    #print(s1,std1)
    if len(std1)==1:
        return std1 in s1
    else:
        fst = std1[0]
        if fst not in s1:
            return False
        fst_idx = s1.find(fst)
        return comp(s1[fst_idx+1:],std1[1:])
if comp(s,std):
    print("YES")
else:
    print("NO")