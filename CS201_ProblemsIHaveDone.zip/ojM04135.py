n,m = map(int,input().split())#m个pocket，共n天
nums = []
for _ in range(n):
    line = int(input().strip())
    nums.append(line)
#print(m,n,nums)
left = min(nums)-1#left一定不行
right = sum(nums)#right一定行
middle = (left+right)//2

def able(x):#表示x是一个可以达到的最大值，即存在一种排法使得最大值小于等于x

    if max(nums)>x:
        return False
    pockets=0
    _count = 0#保证_count<x
    for i in range(n):
        _count+=nums[i]
        if _count>x:
            _count=nums[i]
            pockets+=1
    return pockets+1<=m
while left < right-1:
    #print(left, middle, right)
    if able(middle):
        right = middle
        middle = (left+right)//2
    else:
        left = middle
        middle = (left + right) // 2

print(right)

