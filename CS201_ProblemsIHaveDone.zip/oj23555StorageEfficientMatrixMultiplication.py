n,m1,m2 = map(int,input().split())
M1 = []
ans = []
for _ in range(n):
    ans.append([0]*n)
def isx(goal,t):
    return t[0]==goal
def isy(goal,t):
    return t[1]==goal
for _ in range(m1):
    x,y,val = map(int,input().split())
    M1.append((x,y,val))
M2 = []
for _ in range(m2):
    x,y,val = map(int,input().split())
    M2.append((x,y,val))
for t1 in M1:
    x1,y1,val1 = t1[0],t1[1],t1[2]
    for t2 in M2:
        x2, y2, val2 = t2[0], t2[1], t2[2]
        if y1==x2:
            ans[x1][y2]+=val1*val2
for i in range(n):
    for j in range(n):
        if ans[i][j]:
            tmp = [i, j, ans[i][j]]
            print(' '.join(map(str,tmp)))
