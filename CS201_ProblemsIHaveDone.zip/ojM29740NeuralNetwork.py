from collections import deque,defaultdict
def topological_sort(graph):
    degree = defaultdict(int)
    result = []
    for u in graph:
        for v in graph[u]:
            degree[v] += 1
    q = deque(u for u in graph if degree[u] == 0)
    while q:
        u = q.popleft()
        result.append(u)
        for v in graph[u]:
            degree[v] -= 1
            if degree[v] == 0:
                q.append(v)
    return result if len(result) == len(graph) else None

n,p = map(int,input().split())
ps = [(0,0)]
for _ in range(n):
    c,u = map(int,input().split())
    ps.append((c,u))
graph0 = [defaultdict(int) for _ in range(n+1)]
for _ in range(p):
    i,j,w = map(int,input().split())
    graph0[i][j]+=w
graph = {i:list(graph0[i].keys()) for i in range(1,n+1)}
order = topological_sort(graph)
if order is None:
    print("NULL")
else:
    indeg = [0]*(n+1)
    outdeg = [0]*(n+1)
    C = [0]*(n+1)
    for i in range(1,n+1):
        for j in graph[i]:
            indeg[j]+=1
        outdeg[i] = len(graph[i])
    for i in order:
        if indeg[i]==0:#第一层
            C[i]=ps[i][0]
        else:
            C[i]-=ps[i][1]
        if C[i]>0:
            for j in graph[i]:
                C[j]+=graph0[i][j]*C[i]
    flag = False
    for i in range(1,n+1):
        if outdeg[i]==0 and C[i]>0:
            print(i,C[i])
            flag = True
    if not flag:
        print("NULL")