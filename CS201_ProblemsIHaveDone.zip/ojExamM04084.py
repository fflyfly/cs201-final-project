from collections import defaultdict,deque
import heapq
v,a =map(int,input().split())
def topological_sort_small_first(graph):
    degree = defaultdict(int)
    nodes = set(graph.keys())
    for u in graph:
        for v in graph[u]:
            degree[v] += 1
            nodes.add(v)

    heap = []
    for u in nodes:
        if degree[u] == 0:
            heapq.heappush(heap, u)

    result = []
    while heap:
        u = heapq.heappop(heap)   # 编号最小的先出
        result.append(u)
        for v in graph.get(u, []):
            degree[v] -= 1
            if degree[v] == 0:
                heapq.heappush(heap, v)

    return result if len(result) == len(nodes) else None
graph = {}
for i in range(v):
    graph[i+1] = []
for _ in range(a):
    s,e = map(int,input().split())
    graph[s].append(e)
for ch in graph:
    graph[ch].sort()
#print(graph)
order = topological_sort_small_first(graph)
ans = [f"v{x}" for x in order]
print(' '.join(ans))