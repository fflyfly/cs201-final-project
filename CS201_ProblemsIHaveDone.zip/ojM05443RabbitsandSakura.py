import sys
import heapq


def main():
    # === 读入并编号所有地点 ===
    data = sys.stdin.read().split()
    it = iter(data)

    try:
        P = int(next(it))      # 地点个数
    except StopIteration:
        return                 # 没有输入，直接退出

    names = []                 # id -> 地点名
    name_to_id = {}            # 地点名 -> id

    for i in range(P):
        name = next(it)        # 每个地点是一个不含空格的字符串
        names.append(name)
        name_to_id[name] = i   # 建立映射

    # === 建图（无向图） ===
    Q = int(next(it))          # 道路条数
    graph = [[] for _ in range(P)]  # 邻接表 graph[u] = [(v, w), ...]

    for _ in range(Q):
        a = next(it)
        b = next(it)
        d = int(next(it))      # 距离（权重）
        u = name_to_id[a]
        v = name_to_id[b]
        graph[u].append((v, d))
        graph[v].append((u, d))   # 无向路，反向也要加一条

    # === 处理每个询问，跑一次 Dijkstra 并输出路径 ===
    R = int(next(it))          # 询问个数
    INF = 10 ** 18
    output_lines = []

    for _ in range(R):
        sa = next(it)          # 起点名
        sb = next(it)          # 终点名
        s = name_to_id[sa]
        t = name_to_id[sb]

        # 起点 = 终点，题目样例里就是直接输出名字
        if s == t:
            output_lines.append(sa)
            continue

        # --- Dijkstra 初始化 ---
        dist = [INF] * P       # dist[i]：起点到 i 的当前最短距离
        prev = [-1] * P        # prev[i]：最短路下，i 的前驱结点
        prev_w = [0] * P       # prev_w[i]：从 prev[i] 到 i 那条边的权重
        dist[s] = 0

        # 小根堆，元素是 (当前距离, 结点编号)
        heap = [(0, s)]

        # --- 主循环：不断从堆里取出“当前距离最小”的结点 ---
        while heap:
            d, u = heapq.heappop(heap)

            # 如果堆里这个条目已经“过期”（有更短的 dist[u] 了），就跳过
            if d != dist[u]:
                continue

            # 提前终止：如果已经弹出了终点，说明 dist[t] 已经是最短路
            if u == t:
                break

            # 遍历 u 的所有邻居 v
            for v, w in graph[u]:
                nd = d + w     # s -> u -> v 的新距离
                if nd < dist[v]:
                    # 找到更短的路，更新 dist 和前驱信息
                    dist[v] = nd
                    prev[v] = u
                    prev_w[v] = w
                    heapq.heappush(heap, (nd, v))

        # === 还原路径 ===
        if dist[t] == INF:
            # 理论上题目应该保证连通，这里简单防御一下
            output_lines.append(sa + "->(INF)->" + sb)
        else:
            path = []          # 存放结点 id：s -> ... -> t
            weights = []       # 存放每条边的长度

            cur = t
            while cur != -1:
                path.append(cur)
                if prev[cur] != -1:
                    weights.append(prev_w[cur])
                cur = prev[cur]

            path.reverse()     # 反转：t->...->s 变成 s->...->t
            weights.reverse()  # 对应的边权也一起反转

            # === 按题目格式输出：A->(w1)->B->(w2)->C ... ===
            parts = []
            for i, node in enumerate(path):
                parts.append(names[node])
                if i + 1 < len(path):
                    parts.append(f"->({weights[i]})->")
            output_lines.append("".join(parts))

    # 最后一次性打印所有结果
    sys.stdout.write("\n".join(output_lines))


if __name__ == "__main__":
    main()