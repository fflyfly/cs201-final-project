n,m = map(int,input().split())
dic = {}
M = []
for i in range(m):
    M.append(list(map(int,input().split())))
class disjoint:
    def __init__(self,k):
        self.parents = list(range(k*2))
        self.rank = [1]*(2*k)
    def find(self,x):
        if self.parents[x]!=x:
            self.parents[x] = self.find(self.parents[x])
        return self.parents[x]
    def union(self,x,y):
        x_rep, y_rep = self.find(x), self.find(y)
        if x_rep == y_rep:
            return
        if self.rank[x_rep]<self.rank[y_rep]:
            self.parents[x_rep] = y_rep

        elif self.rank[x_rep]>self.rank[y_rep]:
            self.parents[y_rep] = x_rep

        else:
            self.parents[y_rep] = x_rep
            self.rank[x_rep] += 1
D = disjoint(n)
f = True
for ch in M:
    p1,p2,flag = ch[0],ch[1],ch[2]
    if flag ==0:
        D.union(p1,p2)
        D.union(p1+n,p2+n)
    else:
        D.union(p1,p2+n)
        D.union(p1+n,p2)
    if D.find(p1)==D.find(p1+n) or D.find(p2)==D.find(p2+n):
        f = False
        break

if f:
    print("YES")
else:
    print("NO")