# Definition for a binary tree node.
from typing import Optional
class TreeNode:
    def __init__(self, val=0, left=None, right=None):
        self.val = val
        self.left = left
        self.right = right
class Solution:
    def sumNumbers(self, root: Optional[TreeNode]) -> int:
        tmp = root.val
        ans = 0

        def dfs(now: Optional[TreeNode]):
            nonlocal tmp,ans
            if not now.left and not now.right:
                #print(tmp)
                ans+=(tmp)
                return

            if now.left:
                tmp*=10
                tmp+=now.left.val
                dfs(now.left)
                tmp -= now.left.val
                tmp/=10
            if now.right:
                tmp*=10
                tmp += now.right.val

                dfs(now.right)
                tmp -= now.right.val
                tmp/=10
        dfs(root)
        return int(ans)
a = Solution()
print(a.sumNumbers(TreeNode(1,TreeNode(2),TreeNode(3))))