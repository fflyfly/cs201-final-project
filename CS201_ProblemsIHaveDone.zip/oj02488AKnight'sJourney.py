
N = int(input())
canx = [-2,-2,-1,-1,1,1,2,2]
cany = [-1,1,-2,2,-2,2,-1,1]
for _ in range(N):
    possible = False
    print(f"Scenario #{_+1}:")
    p,q = map(int,input().strip().split())
    used = []
    for i in range(p):
        used.append([False]*q)

    now = []
    def able(x,y):
        return 0 <= x < p and 0 <= y < q
    def show(now):
        ans = ""
        for ch in now:
            x,y = ch[0],ch[1]
            ans+=chr(65+y)
            ans+=str(x+1)
        print(ans)


    def dfs(x=0, y=0):
        global possible  # 如果你放在函数里，或用 global 保持一致
        if len(now) == p * q:  # O(1) 的收敛判定
            possible = True
            show(now)
            return True

        # 先收集可走邻居，按“格子名”字典序排序
        cand = []

        for dx,dy in zip(canx,cany):
            tmpx,tmpy = x+dx,y+dy
            if able(tmpx,tmpy) and not used[tmpx][tmpy]:
                name = chr(tmpy+65)+str(tmpx+1)
                cand.append((name,tmpx,tmpy))
        cand.sort(key = lambda t:t[0])
        # 再按排序后的顺序尝试
        for _, nx, ny in cand:
            used[nx][ny] = True
            now.append((nx, ny))
            if dfs(nx, ny):
                return True
            now.pop()
            used[nx][ny] = False

        return False
    for j in range(q):
        for i in range(p):
            used[i][j] = True
            now.append((i,j))
            if len(now)==p*q:
                possible = True
                show(now)
                break
            if dfs(i,j):
                break
            used[i][j] = False
            now.pop()
        if possible:
            break
    if not possible:
        print("impossible")
    if _<N-1:
        print()
