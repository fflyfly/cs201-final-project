class Trie:
    __slots__ = ("ch", "end")
    def __init__(self):
        self.ch = [[-1]*10]   # children indices
        self.end = [False]    # is_end

    def insert(self, word: str) -> None:
        node = 0
        for c in word:
            i = int(c)
            nxt = self.ch[node][i]
            if nxt == -1:
                nxt = len(self.ch)
                self.ch[node][i] = nxt
                self.ch.append([-1]*10)
                self.end.append(False)
            node = nxt
        self.end[node] = True

    def search(self, word: str) -> bool:
        node = 0
        for c in word:
            i = int(c)
            node = self.ch[node][i]
            if node == -1:
                return False
        return self.end[node]

    def startsWith(self, prefix: str) -> bool:
        node = 0
        for c in prefix:
            i = int(c)
            node = self.ch[node][i]
            if node == -1:
                return False
        return True

    # 可选：返回prefix对应的节点下标（很多题要用）
    def walk(self, s: str) -> int:
        node = 0
        for c in s:
            i = int(c)
            node = self.ch[node][i]
            if node == -1:
                return -1
        return node

t = int(input())
for _ in range(t):
    n = int(input())
    trie = Trie()
    flag = True
    all = []
    for __ in range(n):
        s = input().strip()
        all.append(s)
    all.sort(key = lambda x: len(x),reverse=True)

    for ch in all:
        if trie.startsWith(ch):
            flag = False
        trie.insert(ch)
    if flag:
        print("YES")
    else:
        print("NO")
