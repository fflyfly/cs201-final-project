from typing import List
class Solution:
    def pathExistenceQueries(self, n: int, nums: List[int], maxDiff: int, queries: List[List[int]]) -> List[bool]:
        class Graph:
            def __init__(self,n):
                self.m = {}
                for i in range(n):
                    self.m[i] = {i}
            def insert(self,st,ed):
                self.m[st].add(ed)
            def can(self,st,ed):
                s,e = min(st,ed),max(st,ed)
                if e in self.m[s]:
                    return True
                if len(self.m[s])==1:
                    return False
                return self.can(max(self.m[s]),e)


        ans = []
        g = Graph(n)
        for i in range(n-1,0,-1):
            if nums[i]-nums[i-1]<=maxDiff:
                g.insert(i-1,i)
        for ch in queries:
            s,e = ch[0],ch[1]
            ans.append(g.can(s,e))
        return ans
a = Solution()
print(a.pathExistenceQueries( n = 4, nums = [2,5,6,8], maxDiff = 2, queries = [[0,1],[0,2],[1,3],[2,3]]))