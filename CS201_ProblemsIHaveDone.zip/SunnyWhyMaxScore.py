class DisjointSet:
    def __init__(self, k):
        self.parents = list(range(k))
        self.rank = [1] * k
    def find(self, x):
        if self.parents[x] != x:
            self.parents[x] = self.find(self.parents[x])
        return self.parents[x]
    def union(self, x, y):
        x_rep, y_rep = self.find(x), self.find(y)
        if x_rep == y_rep:
            return
        if self.rank[x_rep] < self.rank[y_rep]:
            self.parents[x_rep] = y_rep
        elif self.rank[x_rep] > self.rank[y_rep]:
            self.parents[y_rep] = x_rep
        else:
            self.parents[y_rep] = x_rep
            self.rank[x_rep] += 1
n,m = map(int,input().split())
d = DisjointSet(n)
lst = list(map(int,input().split()))
score = [-1]+lst
#print(score)
for _ in range(m):
    a,b = map(int,input().split())
    d.union(a-1,b-1)
ultparents = []
for i in range(1,n+1):
    ultparents.append(d.find(i-1))#获取每个儿子对应的代表元素，存储在list里面
parent_to_son = {}#获取每个代表元素对应的所有儿子，存储在dict里面
for i,ch in enumerate(ultparents):
    if ch not in parent_to_son:
        parent_to_son[ch] = []
    parent_to_son[ch].append(score[i+1])
#print(parent_to_son)
print(len(parent_to_son.keys()))
ans = []
for ch in parent_to_son:
    ans.append(max(parent_to_son[ch]))
ans.sort(reverse=True)
ans1 = [str(x) for x in ans]
print(' '.join(ans1))