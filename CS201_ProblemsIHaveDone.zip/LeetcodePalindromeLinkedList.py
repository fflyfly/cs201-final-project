# Definition for singly-linked list.
class ListNode:
    def __init__(self, val=0, next=None):
        self.val = val
        self.next = next
class Solution:
    def _reverse(self,head:ListNode)->ListNode:#p c
        pre,cur = None,head
        while cur:
            now = cur
            cur = cur.next
            now.next = pre
            pre = now
        return pre
    def isPalindrome(self, head: ListNode) -> bool:
        first = head
        slow,fast = head,head
        while fast and fast.next:
            slow = slow.next
            fast = fast.next.next
        second = self._reverse(slow)
        ok = True
        p1,p2 = head,second
        while p2:
            if p1.val!=p2.val:
                ok = False
                break
            p1 = p1.next
            p2 = p2.next
        return ok


