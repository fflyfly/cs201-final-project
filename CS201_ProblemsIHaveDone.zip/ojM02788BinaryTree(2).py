import math
while True:
    m,n = map(int,input().split())
    if not(n or m):
        break
    c1 = int(math.log(n,2))+1
    c2 = int(math.log(m,2))+1
    if c2==c1:
        cnt = 1
    else:
        last = m
        for j in range(c1-c2):
            last = last*2+1
        last = min(n,last)
        if n<m*(2**(c1-c2)):
            cnt = 2**(c1-c2)-1
        else:
            cnt=2**(c1-c2)+last-m*(2**(c1-c2))
    print(cnt)