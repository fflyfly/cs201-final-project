s = input().split()
stack = []
computes = ['+','-','*','/']
for ch in s:
    if ch in computes:
        stack.append(ch)
    else:
        stack.append(float(ch))
    while len(stack)>=3 and isinstance(stack[-1], float) and isinstance(stack[-2], float):
        num1 = stack.pop()
        num2 = stack.pop()
        compute = stack.pop()
        if compute == '+':
            stack.append(num1 + num2)
        elif compute == '-':
            stack.append(num2 - num1)
        elif compute == '*':
            stack.append(num1 * num2)
        elif compute == '/':
            stack.append(num2 / num1)
ans = stack.pop()
print("%f\n" % ans)