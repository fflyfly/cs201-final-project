n,m = map(int,input().split())
cost = []
for _ in range(n):
    cost.append(int(input().strip()))
def valid(x):
    if x<max(cost):
        return False
    global m
    cnt = 1
    tmp = 0
    for i in range(n):
        if tmp+cost[i]<=x:
            tmp+=cost[i]
        else:
            tmp = cost[i]
            cnt+=1
    #print(x,cnt)
    return cnt<=m
def search(small,large):
    left,right = small,large
    while left<right:
        mid = (left+right)//2
        if valid(mid):
            right = mid
        else:
            left = mid+1
    return left
small = min(cost)-1
large = sum(cost)
print(search(small,large))