from collections import deque
n = int(input())
for _ in range(n):
    r,c = map(int,input().split())
    m,time = [],[]
    move = [(-1,0),(0,1),(1,0),(0,-1)]
    stx,sty = 0,0
    flag = 0
    ans = 0
    for i in range(r):
        m.append(input())
        time.append([0]*c)
        if 'S' in m[i]:
            stx,sty = i,m[i].find('S')
    def isin(x,y):
        return 0<=x<r and 0<=y<c
    q = deque()
    q.append((stx,sty,0))
    while q:
        nowx,nowy,step = q.popleft()
        for i in range(4):
            dx,dy = move[i]
            nxtx,nxty = nowx+dx,nowy+dy
            if isin(nxtx,nxty) and not time[nxtx][nxty] and m[nxtx][nxty]!='#':
                time[nxtx][nxty] = step+1
                if m[nxtx][nxty]=='E':
                    ans = step+1
                    flag = 1
                    break
                q.append((nxtx,nxty,step+1))
        if flag:
            break
    if flag:
        print(ans)
    else:
        print("oop!")



