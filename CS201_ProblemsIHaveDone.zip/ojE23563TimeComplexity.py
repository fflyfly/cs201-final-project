s = input().strip()
maxi = 0
cnt=1
while True:
    #print(s)

    end = s.find('+')
    if end==-1:
        now = s
    else:
        now = s[:end]
    #print(end)

    #print(now)
    temp1 = now.find('n')
    if temp1 == 0:
        xishu = 1
    else:
        xishu = int(now[:temp1])
    temp2 = now.find('^')
    if xishu!=0:

        cishu = int(now[temp2+1:])
        maxi = max(maxi,cishu)
    s = s[end+1:]
    #print(s)
    if cnt==0:
        break
    if s.find('+')==-1:
        cnt-=1
print(f"n^{maxi}")
