s = input().strip()
ans = 0
for i in range(len(s)):
    #print(s[i])
    ans = ans*26+(ord(s[i])-64)
    #print(ans)
print(ans)