s = list(map(int,input().strip().split()))
votes = {}
for x in s:
    if x not in votes:
        votes[x]=0
    votes[x]+=1
max_value = max(votes.values())
max_keys = [k for k,v in votes.items() if v==max_value]
max_keys = sorted(max_keys)
out = ""
for i in range(len(max_keys)):
    out+=str(max_keys[i])
    if i!=len(max_keys)-1:
        out+=" "
print(out)
