class Solution:
    def removeKdigits(self, num: str, k: int) -> str:
        nums = list(map(int," ".join(num).split()))

        def find_next_greater(nums):
            n = len(nums)
            res = [0] * n
            stack = []
            for i in range(n):
                while stack and nums[i] > nums[stack[-1]]:
                    res[stack.pop()] = i
                stack.append(i)
            while stack:
                res[stack.pop()] = n
            return res
        reversed_nums = nums[::-1]
        res0 = find_next_greater(reversed_nums)
        res1 = res0[::-1]

        for i in range(k):

a = Solution()
print(a.removeKdigits("1432219",1))