from typing import Optional
class TreeNode:
    def __init__(self,left = None,right = None,val = 0):
        self.left = left
        self.right = right
        self.val = val
nums = []
n = int(input())
root = TreeNode(val = 10)
for _ in range(n):
    l,r = map(int,input().split())
    nums.append((l,r))
ans= 1
tmp = 1
def dfs(x):
    global tmp,ans
    l = nums[x-1][0]
    r = nums[x-1][1]
    if l==-1 and r==-1:
        ans = max(tmp,ans)
        return
    if l>0:
        tmp+=1
        dfs(l)
        tmp-=1
    if r>0:
        tmp += 1
        dfs(r)
        tmp -= 1
dfs(1)
print(ans)