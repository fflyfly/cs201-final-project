hao = ['+','-','*','/']
n = int(input())
for _ in range(n):
    s = list(input().split())
    #print(s)
    stack = []
    for ch in s:
        if ch not in hao:
            stack.append(float(ch))
        else:
            num2 = stack.pop()
            num1 = stack.pop()
            if ch == '+':
                stack.append(num1+num2)
            elif ch == '-':
                stack.append(num1 - num2)
            elif ch == '*':
                stack.append(num1 * num2)
            elif ch == '/':
                stack.append(num1 / num2)
    ans = stack.pop()
    print(f"{ans:.2f}")


