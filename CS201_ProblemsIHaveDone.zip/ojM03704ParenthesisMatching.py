import sys
for line in sys.stdin:
    s = line.strip()
    pocket = []
    mark = [' ']*len(s)
    for i,ch in enumerate(s):#i index; ch value
        if ch=='(':
            pocket.append(i)
        elif ch==')':
            if pocket:
                pocket.pop()
            else:
                mark[i] = '?'
    for i in pocket:
        mark[i] = '$'
    print(s)
    print(''.join(mark))