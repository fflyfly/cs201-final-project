from collections import deque
r,c,k = map(int,input().split())
pic = []
sx,sy,ex,ey = 0,0,0,0
px = [-1,0,1,0]#上右下左
py = [0,1,0,-1]
used = []
dist = []#dist[x][y][k]表示x,y处位移次数<=k时到达此地的最小步数
ans = -1
nowcnt = 0
flash = 0
def able(x,y):
    return 0<=x<=r-1 and 0<=y<=c-1
for i in range(r):
    tmp = str(input().strip())
    pic.append(tmp)
    used.append([False]*len(tmp))
    tmp1 = []
    for j in range(c):
        tmp1.append([-1]*k)
    dist.append(tmp1)
    dist.append([-1] * len(tmp))
    if 'S' in tmp:
        sx,sy = i,tmp.find('S')
    elif 'E' in tmp:
        ex,ey = i,tmp.find('E')
q = deque()
q.append((sx,sy))
dist[sx][sy][0] = 0
flag = False
while q:
    bx,by = q.popleft()
    for i in range(4):
        nx,ny = bx+px[i],by+py[i]
        if able(nx,ny):#不管走没走过都试一下，如果更新了就入队
            if pic[nx][ny]=='.':
                j = 0
                while dist[bx][by][j]>=0:
                    if dist[nx][ny][j]==0:
                        dist[nx][ny][j]=dist[bx][by][j]+1
                    else:
                         dist[nx][ny][j] = min(dist[bx][by][j]+1,dist[nx][ny][j])
                    j+=1
                q.append((nx,ny))
            elif pic[nx][ny]=='E':
                j = 0
                while dist[bx][by][j] >= 0:
                    dist[nx][ny][j] = dist[bx][by][j] + 1
                    j += 1
                ans = max(dist[nx][ny])
                flag = True
                break
            elif pic[nx][ny]=='#' and magic[bx][by]+1<k:
                dist[nx][ny] = dist[bx][by] + 1
                q.append((nx, ny))


    if flag:
        break

print(ans)

