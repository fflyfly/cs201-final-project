prec = {'or':1,'and':2,'not':3}
assoc = {'or':'L','and':'L','not':'R'}

def token(s):
    ans = []
    now = 0
    for i, ch in enumerate(s):
        if ch == ' ':
            if i > now:
                ans.append(s[now:i])
            now = i + 1
    if now < len(s):
        ans.append(s[now:])
    # 统一小写运算符/保留操作数原样
    out = []
    for t in ans:
        tl = t.lower()
        out.append(tl if tl in ('and','or','not','(',')') else t)
    return out

def build_stack(tk):
    stack = []
    ans = []
    for ch in tk:
        if ch == '(':
            stack.append(ch)
        elif ch == ')':
            while stack and stack[-1] != '(':
                ans.append(stack.pop())
            if stack and stack[-1] == '(':
                stack.pop()
        elif ch in prec:
            while stack and stack[-1] in prec:
                a, b = prec[ch], prec[stack[-1]]
                if (assoc[ch]=='L' and b>=a) or (assoc[ch]=='R' and b>a):
                    ans.append(stack.pop())
                else:
                    break
            stack.append(ch)
        else:
            ans.append(ch)
    while stack:
        ans.append(stack.pop())
    return ans

class Node:
    def __init__(self, op=None, left=None, right=None, val=None):
        self.op, self.left, self.right, self.val = op, left, right, val

def build_tree(stk):
    st = []
    for ch in stk:
        if ch in ('and','or'):
            r = st.pop()
            l = st.pop()
            st.append(Node(op=ch, left=l, right=r))
        elif ch == 'not':
            a = st.pop()
            st.append(Node(op='not', left=a))
        else:
            st.append(Node(val=ch))
    return st[-1]

def findp(nd):
    if nd.val is not None:
        return 100
    return prec[nd.op]

def isbi(x):
    return x.val is None and x.op in ('and','or')

def needkh(child, prt_op):
    if prt_op in ('and','or'):
        return findp(child) < prec[prt_op]
    if prt_op == 'not':
        return isbi(child)
    return False

def out(tree, prtop=None):
    if tree.val is not None:
        return tree.val
    if tree.op == 'not':
        s = out(tree.left, 'not')
        return 'not ' + ('( ' + s + ' )' if needkh(tree.left, 'not') else s)
    # 二元
    L = out(tree.left, tree.op)
    R = out(tree.right, tree.op)
    if needkh(tree.left, tree.op):
        L = '( ' + L + ' )'
    if needkh(tree.right, tree.op):
        R = '( ' + R + ' )'
    return f"{L} {tree.op} {R}"

def op(s):
    tk = token(s)
    stk = build_stack(tk)
    tree = build_tree(stk)
    return out(tree)

s = input().strip()
print(op(s))
