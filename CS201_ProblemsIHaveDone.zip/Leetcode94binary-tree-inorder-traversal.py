from typing import Optional,List
class TreeNode:
    def __init__(self, val=0, left=None, right=None):
        self.val = val
        self.left = left
        self.right = right
class Solution:
    def inorderTraversal(self, root: Optional[TreeNode]) -> List[int]:
        if not root:
            return []
        ans = self.inorderTraversal(root.left)
        ans .append(root.val)
        ans +=self.inorderTraversal(root.right)
        return ans
a = Solution()
b = TreeNode(2)
b.left = TreeNode(1)
b.right = TreeNode(3)
print(a.inorderTraversal(b))
