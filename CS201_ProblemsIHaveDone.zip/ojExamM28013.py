from collections import deque

class TreeNode:
    def __init__(self,val,left = None,right = None):
        self.val = val
        self.left = left
        self.right = right
n = int(input())
lst = list(map(int,input().split()))
q = deque()
root = TreeNode(lst[0])
q.append(root)
i = 1
while q:
    now = q.popleft()
    if i<n:
        left = lst[i]
        l = TreeNode(left)
        now.left = l
        i+=1
        q.append(l)
    if i<n:
        right = lst[i]
        r = TreeNode(right)
        now.right = r
        i+=1
        q.append(r)
def judgemaxheap(root):
    if root.left and root.left.val>root.val:
        return False
    if root.right and root.right.val>root.val:
        return False
    return (not root.left or judgemaxheap(root.left)) and (not root.right or judgemaxheap(root.right))
def judgeminheap(root):
    if root.left and root.left.val<root.val:
        return False
    if root.right and root.right.val<root.val:
        return False
    return (not root.left or judgeminheap(root.left)) and (not root.right or judgeminheap(root.right))
nowpath = []
def dfs(root):
    nowpath.append(root.val)
    if not root.left and not root.right:
        print(' '.join([str(x) for x in nowpath]))
        nowpath.pop()
        return
    if root.right:
        dfs(root.right)
    if root.left:
        dfs(root.left)

    nowpath.pop()
dfs(root)

if judgemaxheap(root):
    print("Max Heap")
elif judgeminheap(root):
    print("Min Heap")
else:
    print("Not Heap")
