s = input().strip()
stack = [-1]
ans = 0
for i, ch in enumerate(s):
    if ch == '(':
        stack.append(i)
    else:
        stack.pop()
        if not stack:
            stack.append(i)
        else:
            ans = max(ans, i - stack[-1])
print(ans)
